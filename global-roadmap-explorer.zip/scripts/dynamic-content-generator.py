#!/usr/bin/env python3
"""
Dynamic Content Generator for Global Roadmap Explorer
Generates personalized learning suggestions and motivational content
"""

import json
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any

class DynamicContentGenerator:
    def __init__(self):
        self.learning_topics = [
            "React Hooks", "TypeScript", "Node.js", "Python", "Machine Learning",
            "Data Structures", "Algorithms", "System Design", "DevOps", "Cloud Computing",
            "Cybersecurity", "Mobile Development", "UI/UX Design", "Database Design",
            "API Development", "Testing", "Git", "Docker", "Kubernetes", "AWS"
        ]
        
        self.motivational_quotes = [
            "Every expert was once a beginner.",
            "The only way to learn is by doing.",
            "Progress, not perfection.",
            "Small steps lead to big changes.",
            "Consistency beats intensity.",
            "Your future self will thank you.",
            "Learning never exhausts the mind.",
            "The best time to plant a tree was 20 years ago. The second best time is now."
        ]
        
        self.challenge_types = [
            "Build a mini project",
            "Read documentation",
            "Watch a tutorial",
            "Practice coding problems",
            "Write a blog post",
            "Contribute to open source",
            "Learn a new concept",
            "Review and refactor code"
        ]

    def generate_daily_challenge(self) -> Dict[str, Any]:
        """Generate a personalized daily challenge"""
        topic = random.choice(self.learning_topics)
        challenge_type = random.choice(self.challenge_types)
        
        return {
            "id": f"challenge_{datetime.now().strftime('%Y%m%d')}",
            "title": f"{challenge_type}: {topic}",
            "description": f"Today's focus is on {topic}. {challenge_type} to deepen your understanding.",
            "difficulty": random.choice(["Beginner", "Intermediate", "Advanced"]),
            "estimated_time": f"{random.randint(15, 120)} minutes",
            "points": random.randint(10, 50),
            "date": datetime.now().isoformat(),
            "category": self._categorize_topic(topic)
        }

    def generate_weekly_goals(self) -> List[Dict[str, Any]]:
        """Generate weekly learning goals"""
        goals = []
        selected_topics = random.sample(self.learning_topics, 3)
        
        for i, topic in enumerate(selected_topics):
            goals.append({
                "id": f"goal_{i+1}",
                "title": f"Master {topic} fundamentals",
                "description": f"Spend time this week learning and practicing {topic}",
                "target_days": random.randint(3, 5),
                "current_progress": 0,
                "category": self._categorize_topic(topic),
                "priority": random.choice(["High", "Medium", "Low"])
            })
        
        return goals

    def generate_motivational_content(self) -> Dict[str, Any]:
        """Generate motivational content for the day"""
        return {
            "quote": random.choice(self.motivational_quotes),
            "tip": self._generate_learning_tip(),
            "fact": self._generate_tech_fact(),
            "encouragement": self._generate_encouragement()
        }

    def generate_streak_milestones(self, current_streak: int) -> List[Dict[str, Any]]:
        """Generate milestone rewards based on current streak"""
        milestones = []
        
        milestone_rewards = {
            7: {"title": "Week Warrior", "reward": "🏆 First week completed!", "points": 100},
            30: {"title": "Monthly Master", "reward": "🎯 30 days of consistency!", "points": 500},
            100: {"title": "Century Champion", "reward": "💎 100 days streak!", "points": 1000},
            365: {"title": "Year Legend", "reward": "👑 Full year of learning!", "points": 5000}
        }
        
        for days, milestone in milestone_rewards.items():
            if current_streak < days:
                days_remaining = days - current_streak
                milestones.append({
                    "target_days": days,
                    "days_remaining": days_remaining,
                    "title": milestone["title"],
                    "reward": milestone["reward"],
                    "points": milestone["points"],
                    "progress_percentage": (current_streak / days) * 100
                })
        
        return milestones

    def _categorize_topic(self, topic: str) -> str:
        """Categorize learning topics"""
        categories = {
            "Frontend": ["React Hooks", "TypeScript", "UI/UX Design"],
            "Backend": ["Node.js", "API Development", "Database Design"],
            "DevOps": ["Docker", "Kubernetes", "AWS", "DevOps"],
            "Data Science": ["Python", "Machine Learning"],
            "Computer Science": ["Data Structures", "Algorithms", "System Design"],
            "Security": ["Cybersecurity"],
            "Mobile": ["Mobile Development"],
            "Tools": ["Git", "Testing"]
        }
        
        for category, topics in categories.items():
            if topic in topics:
                return category
        return "General"

    def _generate_learning_tip(self) -> str:
        """Generate a random learning tip"""
        tips = [
            "Break complex topics into smaller, manageable chunks",
            "Practice active recall by explaining concepts out loud",
            "Use the Pomodoro Technique for focused learning sessions",
            "Build projects to apply what you've learned",
            "Join communities to learn from others",
            "Keep a learning journal to track your progress",
            "Don't be afraid to make mistakes - they're part of learning",
            "Review and revisit topics regularly to reinforce memory"
        ]
        return random.choice(tips)

    def _generate_tech_fact(self) -> str:
        """Generate an interesting tech fact"""
        facts = [
            "The first computer bug was an actual bug - a moth found in a Harvard computer in 1947",
            "Python was named after Monty Python's Flying Circus, not the snake",
            "The term 'debugging' was coined by Grace Hopper",
            "JavaScript was created in just 10 days by Brendan Eich",
            "The first website ever created is still online: info.cern.ch",
            "Git was created by Linus Torvalds in just 2 weeks",
            "The '@' symbol was used in email for the first time in 1971"
        ]
        return random.choice(facts)

    def _generate_encouragement(self) -> str:
        """Generate encouraging message"""
        messages = [
            "You're making great progress! Keep it up!",
            "Every line of code you write makes you a better developer",
            "Learning is a journey, not a destination",
            "Your dedication to learning is inspiring",
            "Small daily improvements lead to stunning results",
            "You're building skills that will last a lifetime",
            "Consistency is your superpower"
        ]
        return random.choice(messages)

def main():
    """Main function to generate and output dynamic content"""
    generator = DynamicContentGenerator()
    
    # Generate all content types
    content = {
        "daily_challenge": generator.generate_daily_challenge(),
        "weekly_goals": generator.generate_weekly_goals(),
        "motivational_content": generator.generate_motivational_content(),
        "streak_milestones": generator.generate_streak_milestones(5),  # Example: 5-day streak
        "generated_at": datetime.now().isoformat()
    }
    
    # Output as JSON for easy consumption by the frontend
    print(json.dumps(content, indent=2))
    
    return content

if __name__ == "__main__":
    main()
