"use client"

import { PopupButton } from "@/components/ui/popup-button"
import { Badge } from "@/components/ui/badge"

interface CommunityStats {
  stars: string
  users: string
  members: string
  starGrowth: string
  userGrowth: string
  memberGrowth: string
}

const stats: CommunityStats = {
  stars: "15.2K",
  users: "125K",
  members: "8.5K",
  starGrowth: "+500",
  userGrowth: "+2.1K",
  memberGrowth: "+300",
}

export function CommunitySection() {
  const handleStarClick = () => {
    window.open("https://github.com/roadmap-explorer/global-roadmap", "_blank")
  }

  const handleRegisterClick = () => {
    console.log("Register clicked")
  }

  const handleDiscordClick = () => {
    window.open("https://discord.gg/ZwUCVkJz", "_blank")
  }

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="max-w-6xl mx-auto text-center">
        {/* Header */}
        <div className="mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-balance mb-4">Join the Community</h2>
          <p className="text-lg text-muted-foreground text-pretty max-w-3xl mx-auto leading-relaxed">
            Global Roadmap Explorer is the{" "}
            <span className="font-semibold text-primary underline decoration-primary/30">
              fastest growing career guidance platform
            </span>{" "}
            and is trusted by hundreds of thousands of developers worldwide.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {/* GitHub Stars */}
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Badge
                variant="secondary"
                className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-100 text-blue-700 border-blue-200"
              >
                <span className="mr-1">⭐</span>
                Top 1% project
              </Badge>
              <div className="text-5xl md:text-6xl font-bold text-foreground mt-4">{stats.stars}</div>
            </div>
            <div className="text-muted-foreground font-medium">GitHub Stars</div>
            <PopupButton variant="outline" size="lg" onClick={handleStarClick} className="w-full max-w-48 group">
              <span>🐙</span>
              Star us on GitHub
              <span className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity">↗</span>
            </PopupButton>
            <p className="text-xs text-muted-foreground">Help us reach #1</p>
          </div>

          {/* Registered Users */}
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Badge
                variant="secondary"
                className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-100 text-green-700 border-green-200"
              >
                <span className="mr-1">👥</span>
                {stats.userGrowth} every month
              </Badge>
              <div className="text-5xl md:text-6xl font-bold text-foreground mt-4">{stats.users}</div>
            </div>
            <div className="text-muted-foreground font-medium">Registered Users</div>
            <PopupButton variant="default" size="lg" onClick={handleRegisterClick} className="w-full max-w-48">
              <span>👤</span>
              Register yourself
            </PopupButton>
            <p className="text-xs text-muted-foreground">Commit to your growth</p>
          </div>

          {/* Discord Members */}
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Badge
                variant="secondary"
                className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-100 text-purple-700 border-purple-200"
              >
                <span className="mr-1">💬</span>
                {stats.memberGrowth} every month
              </Badge>
              <div className="text-5xl md:text-6xl font-bold text-foreground mt-4">{stats.members}</div>
            </div>
            <div className="text-muted-foreground font-medium">Discord Members</div>
            <PopupButton
              variant="outline"
              size="lg"
              onClick={handleDiscordClick}
              className="w-full max-w-48 group bg-[#5865F2] hover:bg-[#4752C4] text-white border-[#5865F2]"
            >
              <span>💬</span>
              Join on Discord
              <span className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity">↗</span>
            </PopupButton>
            <p className="text-xs text-muted-foreground">Join the community</p>
          </div>
        </div>

        {/* Additional Community Features */}
        <div className="mt-16 pt-8 border-t border-border/50">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-foreground">50+</div>
              <div className="text-sm text-muted-foreground">Career Paths</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">1M+</div>
              <div className="text-sm text-muted-foreground">Roadmaps Created</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">95%</div>
              <div className="text-sm text-muted-foreground">Success Rate</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-foreground">24/7</div>
              <div className="text-sm text-muted-foreground">Community Support</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
