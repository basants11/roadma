"use client"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { FormField } from "@/components/ui/form-field"
import { PopupButton } from "@/components/ui/popup-button"
import { TooltipHelper, TooltipProvider } from "@/components/ui/tooltip-helper"
import { cn } from "@/lib/utils"

interface SubscriptionModalProps {
  isOpen: boolean
  onClose: () => void
}

export function SubscriptionModal({ isOpen, onClose }: SubscriptionModalProps) {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [error, setError] = useState("")

  const handleSubscribe = async () => {
    if (!email || !email.includes("@")) {
      setError("Please enter a valid email address")
      return
    }

    setIsLoading(true)
    setError("")

    try {
      const response = await fetch("/api/subscribe", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        setIsSubscribed(true)
        setTimeout(() => {
          onClose()
          setIsSubscribed(false)
          setEmail("")
        }, 3000)
      } else {
        setError(data.error || "Failed to subscribe. Please try again.")
      }
    } catch (err) {
      setError("Network error. Please check your connection.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleClose = () => {
    onClose()
    setEmail("")
    setError("")
    setIsSubscribed(false)
  }

  return (
    <TooltipProvider>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent
          className={cn(
            "sm:max-w-md bg-background/95 backdrop-blur-md border-border/50 shadow-2xl",
            "animate-in fade-in-0 zoom-in-95 slide-in-from-bottom-8 duration-300",
          )}
        >
          <DialogHeader className="animate-in fade-in-0 slide-in-from-top-4 duration-500">
            <DialogTitle className="flex items-center gap-2">
              <div className="relative">
                <span className="text-lg animate-pulse">🔔</span>
                <span className="text-xs text-primary/60 absolute -top-1 -right-1 animate-bounce">✨</span>
              </div>
              <span className="bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
                Subscribe for Updates
              </span>
            </DialogTitle>
          </DialogHeader>

          {isSubscribed ? (
            <div className="text-center py-8 animate-in fade-in-0 zoom-in-95 duration-500">
              <div className="w-20 h-20 bg-gradient-to-br from-green-100 to-green-200 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                <span className="text-3xl animate-pulse">✅</span>
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2 animate-in slide-in-from-bottom-2 duration-300">
                Successfully Subscribed! 🎉
              </h3>
              <p className="text-muted-foreground animate-in slide-in-from-bottom-4 duration-500">
                You'll receive notifications about new features and updates.
              </p>
              <div className="mt-4 flex justify-center">
                <div className="flex space-x-1">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="w-2 h-2 bg-green-500 rounded-full animate-pulse"
                      style={{ animationDelay: `${i * 0.2}s` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
              <div className="text-center relative">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-blue-500/10 rounded-lg -z-10" />
                <p className="text-muted-foreground p-4">
                  Get notified about new roadmaps, features, and learning resources. ✨
                </p>
              </div>

              <div className="space-y-4">
                <FormField
                  label="Email Address"
                  value={email}
                  onChange={setEmail}
                  placeholder="your.email@gmail.com"
                  type="email"
                  icon={<span>📧</span>}
                  microcopy="We'll send you updates about new features"
                  error={error}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !isLoading) {
                      handleSubscribe()
                    }
                  }}
                />

                <div className="flex gap-3">
                  <PopupButton
                    onClick={handleSubscribe}
                    disabled={isLoading || !email}
                    className="flex-1 relative overflow-hidden"
                    variant="default"
                    glowEffect={true}
                    magneticEffect={true}
                    bounceOnClick={true}
                  >
                    {isLoading ? (
                      <>
                        <span className="mr-2 inline-block animate-spin">⏳</span>
                        Subscribing...
                      </>
                    ) : (
                      <>
                        <span className="mr-2">🔔</span>
                        Subscribe
                      </>
                    )}
                  </PopupButton>

                  <TooltipHelper content="Cancel subscription">
                    <PopupButton onClick={handleClose} variant="outline" size="default" bounceOnClick={true}>
                      <span>✕</span>
                    </PopupButton>
                  </TooltipHelper>
                </div>
              </div>

              <div className="text-xs text-muted-foreground text-center space-y-1 animate-in fade-in-0 duration-700">
                <p className="flex items-center justify-center gap-1">
                  <span>✨</span> No spam, unsubscribe anytime
                </p>
                <p className="flex items-center justify-center gap-1">🔒 Your email is safe with us</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </TooltipProvider>
  )
}
