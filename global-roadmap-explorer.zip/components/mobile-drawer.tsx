"use client"

import type React from "react"
import { useEffect, useRef } from "react"
import { Icons } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface MobileDrawerProps {
  isOpen: boolean
  onClose: () => void
  children: React.ReactNode
  title?: string
}

export function MobileDrawer({ isOpen, onClose, children, title }: MobileDrawerProps) {
  const drawerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden"
      // Focus the drawer for accessibility
      drawerRef.current?.focus()
    } else {
      document.body.style.overflow = "unset"
    }

    return () => {
      document.body.style.overflow = "unset"
    }
  }, [isOpen])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) {
        onClose()
      }
    }

    document.addEventListener("keydown", handleEscape)
    return () => document.removeEventListener("keydown", handleEscape)
  }, [isOpen, onClose])

  return (
    <>
      <div
        className={cn(
          "fixed inset-0 bg-black/60 z-40 transition-all duration-300 md:hidden backdrop-blur-sm",
          isOpen ? "opacity-100 visible" : "opacity-0 invisible",
        )}
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        ref={drawerRef}
        className={cn(
          "fixed left-0 top-0 h-full w-80 bg-card border-r border-border z-50 transition-all duration-300 md:hidden flex flex-col shadow-2xl",
          isOpen ? "translate-x-0 opacity-100" : "-translate-x-full opacity-0",
        )}
        role="dialog"
        aria-modal="true"
        aria-labelledby="drawer-title"
        tabIndex={-1}
      >
        <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
          <h2 id="drawer-title" className="text-lg font-semibold text-foreground">
            {title || "Menu"}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="hover:bg-destructive/10 hover:text-destructive transition-colors"
            aria-label="Close menu"
          >
            <Icons.X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex-1 overflow-hidden flex flex-col">{children}</div>

        <div className="p-2 border-t border-border bg-muted/20">
          <p className="text-xs text-muted-foreground text-center">Swipe left or tap outside to close</p>
        </div>
      </div>
    </>
  )
}
