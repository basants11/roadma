"use client"

import { cn } from "@/lib/utils"

import type React from "react"

import { useState, useCallback, useEffect } from "react"
import { Icons } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MobileDrawer } from "./mobile-drawer"
import { TreeNavigation } from "./tree-navigation"
import { AdvancedSearch } from "./advanced-search"
import { AITutorDropdown } from "./ai-tutor-dropdown"
import { AITutorModal } from "./ai-tutor-modal"
import type { Role } from "@/lib/mock-data"

interface ResponsiveLayoutProps {
  roles: Role[]
  filteredRoles: Role[]
  selectedRole: Role | null
  searchQuery: string
  expandedNodes: Set<string>
  onRoleSelect: (role: Role) => void
  onToggleNode: (nodeId: string) => void
  onFilteredRoles: (roles: Role[]) => void
  onSearchQueryChange: (query: string) => void
  children: React.ReactNode
}

export function ResponsiveLayout({
  roles,
  filteredRoles,
  selectedRole,
  searchQuery,
  expandedNodes,
  onRoleSelect,
  onToggleNode,
  onFilteredRoles,
  onSearchQueryChange,
  children,
}: ResponsiveLayoutProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isMobile, setIsMobile] = useState(false)
  const [aiTutorModalOpen, setAiTutorModalOpen] = useState(false)
  const [selectedAIFeature, setSelectedAIFeature] = useState("")

  useEffect(() => {
    let timeoutId: NodeJS.Timeout

    const checkMobile = () => {
      clearTimeout(timeoutId)
      timeoutId = setTimeout(() => {
        setIsMobile(window.innerWidth < 768)
      }, 100)
    }

    checkMobile()
    window.addEventListener("resize", checkMobile)
    return () => {
      window.removeEventListener("resize", checkMobile)
      clearTimeout(timeoutId)
    }
  }, [])

  const handleRoleSelect = useCallback(
    (role: Role) => {
      onRoleSelect(role)
      if (isMobile) {
        setTimeout(() => {
          setIsMobileMenuOpen(false)
        }, 150)
      }
    },
    [onRoleSelect, isMobile],
  )

  const handleBackToSearch = useCallback(() => {
    onRoleSelect(null)
    if (searchQuery) {
      onSearchQueryChange("")
      onFilteredRoles(roles)
    }
  }, [onRoleSelect, searchQuery, onSearchQueryChange, onFilteredRoles, roles])

  const handleAIFeatureSelect = (feature: string) => {
    setSelectedAIFeature(feature)
    setAiTutorModalOpen(true)
  }

  useEffect(() => {
    if (selectedRole && isMobile) {
      setIsMobileMenuOpen(false)
    }
  }, [selectedRole, isMobile])

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/95 backdrop-blur-sm sticky top-0 z-30 transition-all duration-200">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "md:hidden transition-all duration-200 hover:bg-primary/10",
                isMobileMenuOpen && "bg-primary/10",
              )}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
            >
              <div className="relative w-5 h-5">
                <Icons.Menu
                  className={cn(
                    "w-5 h-5 absolute transition-all duration-200",
                    isMobileMenuOpen ? "rotate-90 opacity-0" : "rotate-0 opacity-100",
                  )}
                />
                <Icons.X
                  className={cn(
                    "w-5 h-5 absolute transition-all duration-200",
                    isMobileMenuOpen ? "rotate-0 opacity-100" : "-rotate-90 opacity-0",
                  )}
                />
              </div>
            </Button>

            {isMobile && selectedRole && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBackToSearch}
                className="md:hidden hover:bg-secondary/80 transition-all duration-200"
                aria-label="Back to search"
              >
                <Icons.ArrowLeft className="w-4 h-4 mr-2 transition-transform group-hover:-translate-x-1" />
                Back
              </Button>
            )}

            <div
              className={cn(
                "transition-all duration-300 ease-in-out",
                isMobile && selectedRole ? "opacity-0 w-0 overflow-hidden" : "opacity-100",
              )}
            >
              <h1 className="text-lg md:text-xl font-bold text-balance">Global Roadmap Explorer</h1>
              <p className="text-xs md:text-sm text-muted-foreground hidden sm:block">Learn. Grow. Master.</p>
            </div>

            {isMobile && selectedRole && (
              <div className="flex-1 min-w-0 animate-in slide-in-from-right-5 duration-300">
                <h1 className="text-lg font-bold truncate">{selectedRole.title}</h1>
                <p className="text-xs text-muted-foreground">{selectedRole.category}</p>
              </div>
            )}
          </div>

          <div className="flex items-center space-x-2">
            <AITutorDropdown onFeatureSelect={handleAIFeatureSelect} />

            <Badge
              variant="outline"
              className={cn(
                "hidden sm:inline-flex transition-all duration-200 hover:bg-primary/10",
                filteredRoles.length === 0 && "text-destructive border-destructive/50",
              )}
            >
              {filteredRoles.length.toLocaleString()} Roles
            </Badge>
            {isMobile && (
              <Badge
                variant="outline"
                className={cn(
                  "text-xs transition-all duration-200",
                  filteredRoles.length === 0 && "text-destructive border-destructive/50",
                )}
              >
                {filteredRoles.length}
              </Badge>
            )}
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-73px)]">
        <aside className="hidden md:block w-80 border-r border-border bg-card/50 backdrop-blur-sm overflow-hidden flex-col">
          <div className="p-4 border-b border-border bg-muted/20">
            <AdvancedSearch
              roles={roles}
              onFilteredRoles={onFilteredRoles}
              searchQuery={searchQuery}
              onSearchQueryChange={onSearchQueryChange}
            />
          </div>

          <div className="flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent">
            {filteredRoles.length > 0 ? (
              <TreeNavigation
                roles={filteredRoles}
                selectedRole={selectedRole}
                onRoleSelect={handleRoleSelect}
                expandedNodes={expandedNodes}
                onToggleNode={onToggleNode}
              />
            ) : (
              <div className="text-center py-8 text-muted-foreground animate-in fade-in-50 duration-500">
                <Icons.Target className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No roles match your criteria</p>
                <p className="text-xs">Try adjusting your search or filters</p>
              </div>
            )}
          </div>
        </aside>

        <MobileDrawer
          isOpen={isMobileMenuOpen}
          onClose={() => setIsMobileMenuOpen(false)}
          title={selectedRole ? "Back to Roles" : "Explore Roles"}
        >
          <div className="p-4 border-b border-border">
            <AdvancedSearch
              roles={roles}
              onFilteredRoles={onFilteredRoles}
              searchQuery={searchQuery}
              onSearchQueryChange={onSearchQueryChange}
            />
          </div>

          <div className="flex-1 overflow-y-auto p-4">
            {filteredRoles.length > 0 ? (
              <TreeNavigation
                roles={filteredRoles}
                selectedRole={selectedRole}
                onRoleSelect={handleRoleSelect}
                expandedNodes={expandedNodes}
                onToggleNode={onToggleNode}
              />
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Icons.Target className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No roles match your criteria</p>
                <p className="text-xs">Try adjusting your search or filters</p>
              </div>
            )}
          </div>
        </MobileDrawer>

        <main className="flex-1 overflow-y-auto transition-all duration-300">{children}</main>
      </div>

      <AITutorModal isOpen={aiTutorModalOpen} onClose={() => setAiTutorModalOpen(false)} feature={selectedAIFeature} />

      <footer className="border-t border-border bg-card/80 backdrop-blur-sm px-4 py-3">
        <div className="flex items-center justify-between text-xs md:text-sm text-muted-foreground">
          <div>© 2025 Global Roadmap Explorer</div>
          <div className="flex space-x-2 md:space-x-4">
            <span className="cursor-pointer hover:text-foreground transition-colors duration-200">Docs</span>
            <span className="cursor-pointer hover:text-foreground transition-colors duration-200">API</span>
            <span className="cursor-pointer hover:text-foreground transition-colors duration-200">Community</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
