"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { PopupButton } from "@/components/ui/popup-button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface AISearchBoxProps {
  onSearch?: (query: string) => void
  placeholder?: string
}

export function AISearchBox({ onSearch, placeholder = "Ask AI about any IT career path..." }: AISearchBoxProps) {
  const [query, setQuery] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [aiResponse, setAiResponse] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [isTyping, setIsTyping] = useState(false)

  useEffect(() => {
    if (query.length > 0) {
      setIsTyping(true)
      const timer = setTimeout(() => setIsTyping(false), 300)
      return () => clearTimeout(timer)
    }
  }, [query])

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()
      if (!query.trim() || isLoading) return

      setIsLoading(true)
      setError(null)
      setAiResponse(null)

      try {
        const response = await fetch("/api/ai-search", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ query: query.trim() }),
          signal: AbortSignal.timeout(10000), // 10 second timeout
        })

        if (!response.ok) {
          throw new Error("Failed to get AI response")
        }

        const data = await response.json()
        setAiResponse(data.response)
        onSearch?.(query)
      } catch (err) {
        console.error("AI Search Error:", err)
        setError("Sorry, I couldn't process your request right now. Please try again.")
      } finally {
        setIsLoading(false)
      }
    },
    [query, isLoading, onSearch],
  )

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <form onSubmit={handleSubmit} className="relative group">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/30 via-accent/20 to-primary/30 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 animate-pulse" />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10 rounded-full blur-xl opacity-50 group-focus-within:opacity-100 transition-all duration-300" />

          <div className="relative bg-card/90 backdrop-blur-md border border-border/50 rounded-full shadow-2xl hover:shadow-primary/20 transition-all duration-300 hover:border-primary/50 group-focus-within:border-primary/70 glow-on-hover">
            <div className="flex items-center px-6 py-5">
              <div className="flex items-center space-x-4 flex-1">
                <div className="relative">
                  {isLoading ? (
                    <div className="relative">
                      <span className="text-lg animate-pulse">🧠</span>
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full animate-ping" />
                    </div>
                  ) : isTyping ? (
                    <span className="text-lg animate-bounce">⚡</span>
                  ) : (
                    <span className="text-lg text-muted-foreground transition-all duration-300 group-hover:text-primary group-focus-within:text-primary">
                      🔍
                    </span>
                  )}
                </div>
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={placeholder}
                  className="border-0 bg-transparent text-lg placeholder:text-muted-foreground/60 focus-visible:ring-0 focus-visible:ring-offset-0 px-0 font-medium"
                  disabled={isLoading}
                />
              </div>

              <PopupButton
                type="submit"
                size="lg"
                disabled={!query.trim() || isLoading}
                className="rounded-full px-6 py-3 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 transition-all duration-200 hover:scale-105 disabled:opacity-50 disabled:hover:scale-100 shadow-lg hover:shadow-primary/30"
                popupText="AI is thinking..."
                successFeedback={true}
                glowEffect={true}
                bounceOnClick={true}
                showRipple={true}
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="animate-spin h-5 w-5 border-2 border-primary-foreground border-t-transparent rounded-full" />
                    <span>✨</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">Ask AI</span>
                    <svg
                      className="h-5 w-5 transition-transform group-hover:translate-x-1"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                    </svg>
                  </div>
                )}
              </PopupButton>
            </div>
          </div>
        </div>
      </form>

      {(aiResponse || error) && (
        <Card className="max-w-4xl mx-auto animate-in slide-in-from-bottom-4 duration-500 shadow-xl border-border/50 bg-card/95 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="flex items-start space-x-4">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-primary/20 shadow-lg text-lg">
                {error ? "❌" : "🧠"}
              </div>
              <div className="flex-1 space-y-3">
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                    <span className="mr-1">✨</span>
                    AI Career Advisor
                  </Badge>
                  {!error && (
                    <Badge variant="outline" className="text-xs">
                      <span className="mr-1">📈</span>
                      Personalized Response
                    </Badge>
                  )}
                </div>
                {error ? (
                  <div className="text-sm text-destructive bg-destructive/10 p-4 rounded-lg border border-destructive/20">
                    {error}
                  </div>
                ) : (
                  <div className="text-sm text-foreground leading-relaxed whitespace-pre-wrap bg-muted/30 p-6 rounded-xl border border-border/30">
                    {aiResponse}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
