"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PopupButton } from "@/components/ui/popup-button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TestTube, Brain, Trophy, ArrowRight } from "lucide-react"

export function TestSkills() {
  const [selectedSkill, setSelectedSkill] = useState("")
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [isActive, setIsActive] = useState(false)
  const [questions, setQuestions] = useState<any[]>([])
  const [selectedAnswer, setSelectedAnswer] = useState("")
  const [showResult, setShowResult] = useState(false)

  const skills = ["JavaScript", "React", "TypeScript", "Node.js", "Python", "CSS", "HTML", "Git", "SQL", "Algorithms"]

  const startTest = async (skill: string) => {
    setSelectedSkill(skill)
    setIsActive(true)
    setCurrentQuestion(0)
    setScore(0)
    setShowResult(false)

    try {
      const response = await fetch("/api/ai-tutor/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ skill }),
      })

      const data = await response.json()
      setQuestions(data.questions || [])
    } catch (error) {
      console.error("Error loading test:", error)
    }
  }

  const submitAnswer = () => {
    if (!selectedAnswer) return

    const isCorrect = selectedAnswer === questions[currentQuestion]?.correct
    if (isCorrect) setScore(score + 1)

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setSelectedAnswer("")
    } else {
      setShowResult(true)
    }
  }

  if (!isActive) {
    return (
      <Card className="border-border/50 bg-card/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TestTube className="h-5 w-5 text-blue-500" />
            <span>Test my Skills</span>
            <Badge variant="secondary" className="bg-blue-500/10 text-blue-600">
              <Brain className="h-3 w-3 mr-1" />
              AI Generated
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Choose a skill to test your knowledge with AI-generated questions
            </p>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {skills.map((skill) => (
                <PopupButton
                  key={skill}
                  variant="outline"
                  size="sm"
                  onClick={() => startTest(skill)}
                  className="justify-start"
                  popupText={`Starting ${skill} test...`}
                  glowEffect={true}
                >
                  {skill}
                </PopupButton>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (showResult) {
    const percentage = Math.round((score / questions.length) * 100)
    return (
      <Card className="border-border/50 bg-card/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-500" />
            <span>Test Results</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center space-y-4">
            <div className="text-4xl font-bold text-primary">{percentage}%</div>
            <div className="text-lg font-medium">
              {score} out of {questions.length} correct
            </div>

            <div className="space-y-2">
              <Progress value={percentage} className="h-3" />
              <div className="text-sm text-muted-foreground">
                {percentage >= 80 ? "Excellent!" : percentage >= 60 ? "Good job!" : "Keep practicing!"}
              </div>
            </div>
          </div>

          <PopupButton onClick={() => setIsActive(false)} className="w-full" popupText="Taking you back...">
            Take Another Test
          </PopupButton>
        </CardContent>
      </Card>
    )
  }

  const question = questions[currentQuestion]
  if (!question) return <div>Loading...</div>

  return (
    <Card className="border-border/50 bg-card/90 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <TestTube className="h-5 w-5 text-blue-500" />
            <span>{selectedSkill} Test</span>
          </CardTitle>
          <Badge variant="outline">
            {currentQuestion + 1} / {questions.length}
          </Badge>
        </div>
        <Progress value={((currentQuestion + 1) / questions.length) * 100} className="h-2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-4">
          <h3 className="font-medium text-lg">{question.question}</h3>

          <div className="space-y-2">
            {question.options?.map((option: string, index: number) => (
              <PopupButton
                key={index}
                variant={selectedAnswer === option ? "default" : "outline"}
                className="w-full justify-start text-left h-auto p-4"
                onClick={() => setSelectedAnswer(option)}
                popupText="Selected!"
              >
                <div className="flex items-center space-x-2">
                  <div className="w-6 h-6 rounded-full border-2 border-current flex items-center justify-center text-xs">
                    {String.fromCharCode(65 + index)}
                  </div>
                  <span>{option}</span>
                </div>
              </PopupButton>
            ))}
          </div>

          <PopupButton
            onClick={submitAnswer}
            disabled={!selectedAnswer}
            className="w-full"
            popupText="Submitting answer..."
            successFeedback={true}
          >
            <div className="flex items-center space-x-2">
              <span>{currentQuestion === questions.length - 1 ? "Finish Test" : "Next Question"}</span>
              <ArrowRight className="h-4 w-4" />
            </div>
          </PopupButton>
        </div>
      </CardContent>
    </Card>
  )
}
