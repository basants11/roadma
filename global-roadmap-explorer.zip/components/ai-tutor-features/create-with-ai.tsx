"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PopupButton } from "@/components/ui/popup-button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, Sparkles, BookOpen, Code, Lightbulb, ArrowRight, Clock, Target } from "lucide-react"

export function CreateWithAI() {
  const [topic, setTopic] = useState("")
  const [level, setLevel] = useState("beginner")
  const [isLoading, setIsLoading] = useState(false)
  const [learningPlan, setLearningPlan] = useState<any>(null)

  const handleGenerate = async () => {
    if (!topic.trim()) return

    setIsLoading(true)
    try {
      const response = await fetch("/api/ai-tutor/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: topic.trim(), level }),
      })

      const data = await response.json()
      setLearningPlan(data.plan)
    } catch (error) {
      console.error("Error generating learning plan:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card className="border-border/50 bg-card/90 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="h-5 w-5 text-green-500" />
            <span>Create with AI</span>
            <Badge variant="secondary" className="bg-green-500/10 text-green-600">
              <Sparkles className="h-3 w-3 mr-1" />
              Personalized
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">What would you like to learn?</label>
            <Input
              placeholder="e.g., React Hooks, Python basics, Machine Learning..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="bg-background/50"
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Your current level</label>
            <div className="flex space-x-2">
              {["beginner", "intermediate", "advanced"].map((lvl) => (
                <PopupButton
                  key={lvl}
                  variant={level === lvl ? "default" : "outline"}
                  size="sm"
                  onClick={() => setLevel(lvl)}
                  className="capitalize"
                  popupText={`Selected ${lvl}`}
                >
                  {lvl}
                </PopupButton>
              ))}
            </div>
          </div>

          <PopupButton
            onClick={handleGenerate}
            disabled={!topic.trim() || isLoading}
            className="w-full"
            popupText="Generating your learning plan..."
            successFeedback={true}
            glowEffect={true}
          >
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <div className="animate-spin h-4 w-4 border-2 border-primary-foreground border-t-transparent rounded-full" />
                <span>Creating your plan...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Lightbulb className="h-4 w-4" />
                <span>Generate Learning Plan</span>
                <ArrowRight className="h-4 w-4" />
              </div>
            )}
          </PopupButton>
        </CardContent>
      </Card>

      {learningPlan && (
        <Card className="border-border/50 bg-card/90 backdrop-blur-sm animate-in slide-in-from-bottom-4">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <span>Your Personalized Learning Plan</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-lg">
                <Clock className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-sm font-medium">Duration</div>
                  <div className="text-xs text-muted-foreground">{learningPlan.duration}</div>
                </div>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-lg">
                <Target className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-sm font-medium">Difficulty</div>
                  <div className="text-xs text-muted-foreground capitalize">{learningPlan.difficulty}</div>
                </div>
              </div>
              <div className="flex items-center space-x-2 p-3 bg-muted/30 rounded-lg">
                <Code className="h-4 w-4 text-purple-500" />
                <div>
                  <div className="text-sm font-medium">Projects</div>
                  <div className="text-xs text-muted-foreground">{learningPlan.projects} hands-on</div>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">Learning Steps:</h4>
              {learningPlan.steps?.map((step: any, index: number) => (
                <div key={index} className="flex items-start space-x-3 p-3 bg-muted/20 rounded-lg">
                  <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium text-primary">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <div className="font-medium text-sm">{step.title}</div>
                    <div className="text-xs text-muted-foreground mt-1">{step.description}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
