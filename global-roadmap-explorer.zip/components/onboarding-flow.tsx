"use client"

import type * as React from "react"
import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PopupButton } from "@/components/ui/popup-button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { FormField } from "@/components/ui/form-field"
import { ArrowRight, ArrowLeft, CheckCircle, Target, User, Rocket, Sparkles } from "lucide-react"

interface OnboardingStep {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  fields: Array<{
    id: string
    label: string
    type?: "text" | "email" | "textarea"
    placeholder: string
    microcopy: string
    tooltip?: string
    required?: boolean
    maxLength?: number
  }>
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: "profile",
    title: "Tell us about you",
    description: "Help us personalize your learning journey",
    icon: <User className="w-6 h-6" />,
    fields: [
      {
        id: "name",
        label: "Your name",
        placeholder: "Enter your first name",
        microcopy: "We'll use this to personalize your experience",
        required: true,
        maxLength: 50,
      },
      {
        id: "experience",
        label: "Current experience",
        type: "textarea",
        placeholder: "Briefly describe your background",
        microcopy: "Help us understand your starting point",
        tooltip: "Include any relevant work, education, or projects",
        maxLength: 200,
      },
    ],
  },
  {
    id: "goals",
    title: "Set your goals",
    description: "What do you want to achieve?",
    icon: <Target className="w-6 h-6" />,
    fields: [
      {
        id: "career-goal",
        label: "Dream career",
        placeholder: "e.g., Full Stack Developer",
        microcopy: "What role do you want to reach?",
        required: true,
        maxLength: 100,
      },
      {
        id: "timeline",
        label: "Target timeline",
        placeholder: "e.g., 6 months, 1 year",
        microcopy: "When do you want to achieve this?",
        maxLength: 50,
      },
    ],
  },
  {
    id: "preferences",
    title: "Learning style",
    description: "How do you learn best?",
    icon: <Rocket className="w-6 h-6" />,
    fields: [
      {
        id: "learning-style",
        label: "Preferred approach",
        type: "textarea",
        placeholder: "e.g., hands-on projects, video tutorials",
        microcopy: "This helps us recommend the right resources",
        tooltip: "Think about how you've learned successfully before",
        maxLength: 150,
      },
    ],
  },
]

interface OnboardingFlowProps {
  onComplete: (data: Record<string, string>) => void
  onSkip?: () => void
}

export function OnboardingFlow({ onComplete, onSkip }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState<Record<string, string>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})

  const progress = ((currentStep + 1) / onboardingSteps.length) * 100
  const isLastStep = currentStep === onboardingSteps.length - 1
  const currentStepData = onboardingSteps[currentStep]

  const validateStep = () => {
    const newErrors: Record<string, string> = {}

    currentStepData.fields.forEach((field) => {
      if (field.required && !formData[field.id]?.trim()) {
        newErrors[field.id] = `${field.label} is required`
      }
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleNext = () => {
    if (!validateStep()) return

    if (isLastStep) {
      onComplete(formData)
    } else {
      setCurrentStep((prev) => prev + 1)
      setErrors({})
    }
  }

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
      setErrors({})
    }
  }

  const updateFormData = (fieldId: string, value: string) => {
    setFormData((prev) => ({ ...prev, [fieldId]: value }))
    if (errors[fieldId]) {
      setErrors((prev) => ({ ...prev, [fieldId]: "" }))
    }
  }

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-2xl border-border/50 bg-card/95 backdrop-blur-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-2">
            <Badge variant="secondary" className="bg-primary/10 text-primary">
              Step {currentStep + 1} of {onboardingSteps.length}
            </Badge>
            {onSkip && (
              <button
                onClick={onSkip}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Skip setup
              </button>
            )}
          </div>

          <Progress value={progress} className="w-full h-2" />

          <div className="flex items-center justify-center w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 border border-primary/20">
            {currentStepData.icon}
          </div>

          <div>
            <CardTitle className="text-2xl font-bold text-balance">{currentStepData.title}</CardTitle>
            <p className="text-muted-foreground text-pretty mt-2">{currentStepData.description}</p>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <div className="space-y-4">
            {currentStepData.fields.map((field) => (
              <FormField
                key={field.id}
                id={field.id}
                label={field.label}
                type={field.type}
                placeholder={field.placeholder}
                microcopy={field.microcopy}
                tooltip={field.tooltip}
                value={formData[field.id] || ""}
                onChange={(value) => updateFormData(field.id, value)}
                error={errors[field.id]}
                success={formData[field.id] && !errors[field.id] ? "Looks good!" : undefined}
                required={field.required}
                maxLength={field.maxLength}
              />
            ))}
          </div>

          <div className="flex items-center justify-between pt-6">
            <PopupButton
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 0}
              className="flex items-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </PopupButton>

            <PopupButton
              onClick={handleNext}
              className="flex items-center space-x-2 bg-gradient-to-r from-primary to-primary/80"
              popupText={isLastStep ? "Setting up your profile..." : "Moving to next step..."}
              successFeedback={true}
              glowEffect={true}
            >
              {isLastStep ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Complete Setup</span>
                  <Sparkles className="w-4 h-4" />
                </>
              ) : (
                <>
                  <span>Continue</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </PopupButton>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
