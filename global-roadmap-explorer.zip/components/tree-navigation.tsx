"use client"

import { useCallback, useMemo } from "react"
import { AnimatedTreeNode } from "./animated-tree-node"
import type { Role } from "@/lib/mock-data"

interface TreeNavigationProps {
  roles: Role[]
  selectedRole: Role | null
  onRoleSelect: (role: Role) => void
  expandedNodes: Set<string>
  onToggleNode: (nodeId: string) => void
}

export function TreeNavigation({
  roles,
  selectedRole,
  onRoleSelect,
  expandedNodes,
  onToggleNode,
}: TreeNavigationProps) {
  // Group roles by category with subcategories
  const groupedRoles = useMemo(() => {
    const groups: { [key: string]: { [key: string]: Role[] } } = {}

    roles.forEach((role) => {
      if (!groups[role.category]) {
        groups[role.category] = {}
      }

      // Create subcategories based on role level
      const subcategory = role.level ? `${role.level.charAt(0).toUpperCase()}${role.level.slice(1)} Level` : "General"

      if (!groups[role.category][subcategory]) {
        groups[role.category][subcategory] = []
      }

      groups[role.category][subcategory].push(role)
    })

    return groups
  }, [roles])

  const renderRoleNodes = useCallback(
    (subcategoryRoles: Role[], categoryName: string, subcategoryName: string) => {
      const displayLimit = 15
      const hasMore = subcategoryRoles.length > displayLimit

      return (
        <div className="ml-6 mt-1 space-y-1">
          {subcategoryRoles.slice(0, displayLimit).map((role) => (
            <AnimatedTreeNode
              key={role.id}
              role={role}
              isExpanded={false}
              isSelected={selectedRole?.id === role.id}
              level={2}
              onToggle={() => {}}
              onSelect={() => onRoleSelect(role)}
            />
          ))}
          {hasMore && (
            <div className="px-3 py-2 text-xs text-muted-foreground bg-muted/30 rounded-md ml-6 animate-pulse">
              +{subcategoryRoles.length - displayLimit} more roles...
            </div>
          )}
        </div>
      )
    },
    [selectedRole, onRoleSelect],
  )

  const renderSubcategoryNodes = useCallback(
    (category: string, subcategories: { [key: string]: Role[] }) => {
      return (
        <div className="ml-4 space-y-1">
          {Object.entries(subcategories).map(([subcategory, subcategoryRoles]) => {
            const subcategoryId = `subcategory-${category}-${subcategory}`
            const isExpanded = expandedNodes.has(subcategoryId)

            return (
              <AnimatedTreeNode
                key={subcategoryId}
                subcategory={subcategory}
                roles={subcategoryRoles}
                isExpanded={isExpanded}
                level={1}
                onToggle={() => onToggleNode(subcategoryId)}
              >
                {renderRoleNodes(subcategoryRoles, category, subcategory)}
              </AnimatedTreeNode>
            )
          })}
        </div>
      )
    },
    [expandedNodes, onToggleNode, renderRoleNodes],
  )

  return (
    <div className="space-y-2">
      {Object.entries(groupedRoles).map(([category, subcategories]) => {
        const categoryId = `category-${category}`
        const isExpanded = expandedNodes.has(categoryId)
        const totalRoles = Object.values(subcategories).reduce((sum, roles) => sum + roles.length, 0)

        return (
          <AnimatedTreeNode
            key={category}
            category={category}
            totalRoles={totalRoles}
            isExpanded={isExpanded}
            level={0}
            onToggle={() => onToggleNode(categoryId)}
          >
            {renderSubcategoryNodes(category, subcategories)}
          </AnimatedTreeNode>
        )
      })}
    </div>
  )
}
