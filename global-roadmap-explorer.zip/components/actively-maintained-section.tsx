"use client"
import { useState } from "react"
import { PopupButton } from "@/components/ui/popup-button"
import { SubscriptionModal } from "@/components/subscription-modal"

const updates = [
  {
    date: "15 Jan, 2025",
    title: "AI-Powered Roadmap Generation and Smart Search",
    description: "Enhanced AI capabilities for personalized learning paths",
  },
  {
    date: "08 Jan, 2025",
    title: "Streak Tracking System and Progress Analytics",
    description: "Daily learning streaks with detailed progress insights",
  },
  {
    date: "02 Jan, 2025",
    title: "Interactive Tree Navigation and Mobile Optimization",
    description: "Improved user experience across all devices",
  },
  {
    date: "28 Dec, 2024",
    title: "Advanced Search Filters and Content Discovery",
    description: "Find exactly what you need with powerful search tools",
  },
  {
    date: "20 Dec, 2024",
    title: "Community Features and Social Learning",
    description: "Connect with fellow learners and share progress",
  },
  {
    date: "15 Dec, 2024",
    title: "Personalized Dashboard and Learning Recommendations",
    description: "Tailored content suggestions based on your goals",
  },
  {
    date: "10 Dec, 2024",
    title: "Multi-Language Support and Accessibility Improvements",
    description: "Making learning accessible to everyone worldwide",
  },
  {
    date: "05 Dec, 2024",
    title: "Real-time Collaboration and Study Groups",
    description: "Learn together with synchronized progress tracking",
  },
]

export function ActivelyMaintainedSection() {
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false)

  return (
    <section className="py-16 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <span className="text-3xl">🚀</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">Actively Maintained</h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            We are always improving our platform, adding new features and enhancing your learning experience with
            cutting-edge technology.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-32 top-0 bottom-0 w-px bg-border"></div>

          <div className="space-y-8">
            {updates.map((update, index) => (
              <div key={index} className="relative flex items-start gap-6">
                {/* Date */}
                <div className="hidden md:block w-28 text-right">
                  <span className="text-sm text-muted-foreground font-medium">{update.date}</span>
                </div>

                {/* Timeline dot */}
                <div className="relative flex-shrink-0">
                  <div className="w-3 h-3 bg-primary rounded-full border-2 border-background shadow-sm"></div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 pb-8">
                  <div className="md:hidden mb-2">
                    <span className="text-sm text-muted-foreground font-medium">{update.date}</span>
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2 leading-tight">{update.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{update.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
          <PopupButton
            variant="default"
            size="lg"
            className="bg-foreground text-background hover:bg-foreground/90 font-semibold px-8"
            onClick={() => {
              console.log("[v0] View Full Changelog clicked")
            }}
          >
            <span className="mr-2">📋</span>
            View Full Changelog
          </PopupButton>

          <PopupButton
            variant="outline"
            size="lg"
            className="font-semibold px-8 border-2"
            onClick={() => setIsSubscriptionModalOpen(true)}
          >
            <span className="mr-2">🔔</span>
            Subscribe for Notifications
          </PopupButton>
        </div>
      </div>

      <SubscriptionModal isOpen={isSubscriptionModalOpen} onClose={() => setIsSubscriptionModalOpen(false)} />
    </section>
  )
}
