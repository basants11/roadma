"use client"

import { useState } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { PopupButton } from "@/components/ui/popup-button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface AITutorDropdownProps {
  onFeatureSelect: (feature: string) => void
}

export function AITutorDropdown({ onFeatureSelect }: AITutorDropdownProps) {
  const [isOpen, setIsOpen] = useState(false)

  const features = [
    {
      id: "create",
      icon: "🎯",
      title: "Create with AI",
      description: "Learn something new with AI",
      color: "text-green-500",
      bgColor: "bg-green-500/10",
      hoverColor: "hover:bg-green-500/20",
    },
    {
      id: "test",
      icon: "🧪",
      title: "Test my Skills",
      description: "Test your skills with AI",
      color: "text-blue-500",
      bgColor: "bg-blue-500/10",
      hoverColor: "hover:bg-blue-500/20",
    },
    {
      id: "ask",
      icon: "💬",
      title: "Ask AI Tutor",
      description: "Career, resume guidance, and more",
      color: "text-purple-500",
      bgColor: "bg-purple-500/10",
      hoverColor: "hover:bg-purple-500/20",
    },
    {
      id: "roadmap-chat",
      icon: "🗺️",
      title: "Roadmap Chat",
      description: "Chat with AI Tutor about a roadmap",
      color: "text-orange-500",
      bgColor: "bg-orange-500/10",
      hoverColor: "hover:bg-orange-500/20",
    },
  ]

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <PopupButton
          variant="outline"
          className={cn(
            "bg-card/90 backdrop-blur-sm border-border/50 hover:border-primary/50 transition-all duration-200",
            isOpen && "bg-primary/10 border-primary/50",
          )}
          popupText="Opening AI Tutor"
          glowEffect={true}
          magneticEffect={true}
        >
          <div className="flex items-center space-x-2 relative z-10">
            <div className="relative">
              <span className="text-lg">🧠</span>
              <span className="text-xs text-primary/60 absolute -top-0.5 -right-0.5 animate-pulse">✨</span>
            </div>
            <span className="font-medium">AI Tutor</span>
            <svg
              className={cn(
                "h-4 w-4 transition-all duration-200 ease-out",
                isOpen ? "rotate-180 text-primary" : "text-muted-foreground",
              )}
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
          {isOpen && <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent animate-pulse" />}
        </PopupButton>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        className={cn(
          "w-80 p-2 bg-card/95 backdrop-blur-md border-border/50 shadow-2xl",
          "animate-in fade-in-0 zoom-in-95 slide-in-from-top-2 duration-200",
        )}
        align="start"
        sideOffset={8}
      >
        <div className="px-3 py-2 mb-2 animate-in fade-in-0 slide-in-from-top-1 duration-300">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="relative">
                <span className="text-lg animate-pulse">🧠</span>
                <span className="text-xs text-primary/60 absolute -top-1 -right-1 animate-bounce">✨</span>
              </div>
              <span className="font-semibold text-sm bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
                AI Tutor
              </span>
            </div>
            <Badge
              variant="secondary"
              className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 text-yellow-600 border-yellow-500/30 animate-pulse hover:scale-105 transition-transform cursor-pointer"
            >
              <span className="mr-1">⚡</span>
              Upgrade to Pro
            </Badge>
          </div>
        </div>

        <DropdownMenuSeparator className="bg-border/50" />

        {features.map((feature, index) => (
          <DropdownMenuItem
            key={feature.id}
            className="p-0 focus:bg-muted/50 cursor-pointer animate-in fade-in-0 slide-in-from-left-2 duration-200"
            style={{ animationDelay: `${index * 30}ms` }}
            onClick={() => {
              onFeatureSelect(feature.id)
              setIsOpen(false)
            }}
          >
            <div
              className={cn(
                "flex items-center space-x-3 p-3 w-full rounded-md transition-all duration-200 group",
                "hover:bg-muted/30 hover:scale-[1.01] hover:shadow-sm",
                feature.hoverColor,
              )}
            >
              <div
                className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-200 group-hover:scale-110 text-lg",
                  feature.bgColor,
                )}
              >
                {feature.icon}
              </div>
              <div className="flex-1">
                <div className="font-medium text-sm text-foreground group-hover:text-primary transition-colors duration-200">
                  {feature.title}
                </div>
                <div className="text-xs text-muted-foreground group-hover:text-muted-foreground/80 transition-colors duration-200">
                  {feature.description}
                </div>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <svg
                  className="h-4 w-4 text-muted-foreground rotate-[-90deg]"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                </svg>
              </div>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
