"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Icons } from "@/components/icons"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { Role } from "@/lib/mock-data"

interface AnimatedTreeNodeProps {
  role?: Role
  category?: string
  subcategory?: string
  roles?: Role[]
  totalRoles?: number
  level: number
  isExpanded: boolean
  isSelected?: boolean
  onToggle: () => void
  onSelect?: () => void
  children?: React.ReactNode
}

export function AnimatedTreeNode({
  role,
  category,
  subcategory,
  roles,
  totalRoles,
  level,
  isExpanded,
  isSelected = false,
  onToggle,
  onSelect,
  children,
}: AnimatedTreeNodeProps) {
  const [height, setHeight] = useState<number | undefined>(isExpanded ? undefined : 0)
  const [isHovered, setIsHovered] = useState(false)
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (contentRef.current) {
      const scrollHeight = contentRef.current.scrollHeight
      if (isExpanded) {
        setHeight(scrollHeight)
        // Reset to auto after animation completes for dynamic content
        setTimeout(() => setHeight(undefined), 300)
      } else {
        setHeight(scrollHeight)
        // Force reflow then animate to 0
        requestAnimationFrame(() => {
          setHeight(0)
        })
      }
    }
  }, [isExpanded, children])

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation()
    onToggle()
  }

  const handleSelect = () => {
    if (onSelect) {
      onSelect()
    }
  }

  const hasChildren = Boolean(children)
  const paddingLeft = level * 16

  if (role) {
    return (
      <div className="animate-in fade-in-0 slide-in-from-left-2 duration-300">
        <button
          onClick={handleSelect}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className={cn(
            "w-full text-left p-3 rounded-lg transition-all duration-300 group relative overflow-hidden",
            "hover:bg-accent/80 hover:scale-[1.02] hover:shadow-md active:scale-[0.98]",
            "focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2",
            isSelected && "bg-primary text-primary-foreground shadow-lg scale-[1.02]",
            isHovered && !isSelected && "bg-gradient-to-r from-accent/50 to-accent/80",
          )}
          style={{ paddingLeft: paddingLeft + 8 }}
        >
          <div
            className={cn(
              "absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-0 transition-opacity duration-300",
              isHovered && "opacity-100",
            )}
          />

          <div className="flex items-center space-x-3 relative z-10">
            <div
              className={cn(
                "transition-all duration-300",
                isSelected ? "text-primary-foreground" : "text-primary",
                isHovered && "scale-110",
              )}
            >
              <Icons.Target className="w-4 h-4 flex-shrink-0" />
            </div>
            <div className="flex-1 min-w-0">
              <div
                className={cn(
                  "text-sm font-medium truncate transition-colors duration-200",
                  isSelected && "text-primary-foreground",
                )}
              >
                {role.title}
              </div>
              <div className="flex items-center space-x-2 mt-1">
                <Badge
                  variant={isSelected ? "secondary" : "outline"}
                  className={cn(
                    "text-xs transition-all duration-200",
                    isSelected && "bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30",
                  )}
                >
                  {role.level}
                </Badge>
                <span
                  className={cn(
                    "text-xs transition-colors duration-200",
                    isSelected ? "text-primary-foreground/80" : "text-muted-foreground",
                  )}
                >
                  {role.estimatedWeeks}w
                </span>
              </div>
            </div>
            {isSelected && <div className="w-2 h-2 bg-primary-foreground rounded-full animate-pulse" />}
          </div>
        </button>
      </div>
    )
  }

  return (
    <div className="animate-in fade-in-0 slide-in-from-left-2 duration-300">
      <button
        onClick={hasChildren ? handleToggle : handleSelect}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        className={cn(
          "w-full text-left p-3 rounded-lg transition-all duration-300 group relative overflow-hidden",
          "hover:bg-accent/80 hover:scale-[1.01] hover:shadow-sm active:scale-[0.99]",
          "focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2",
          level === 0 && "font-semibold bg-muted/30",
          level === 1 && "font-medium",
        )}
        style={{ paddingLeft }}
      >
        <div
          className={cn(
            "absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-0 transition-opacity duration-300",
            isHovered && "opacity-100",
          )}
        />

        <div className="flex items-center space-x-3 relative z-10">
          {hasChildren && (
            <div
              className={cn(
                "transition-all duration-300 ease-out",
                isExpanded && "rotate-90",
                isHovered && "scale-110",
              )}
            >
              <Icons.ChevronRight className="w-4 h-4 text-muted-foreground" />
            </div>
          )}

          <div className={cn("transition-all duration-300", isHovered && "scale-110")}>
            {isExpanded ? (
              <Icons.FolderOpen className="w-4 h-4 text-primary animate-in zoom-in-50 duration-200" />
            ) : (
              <Icons.Folder className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-200" />
            )}
          </div>

          <span
            className={cn(
              "text-sm truncate transition-colors duration-200",
              level === 0 && "text-foreground",
              level > 0 && "text-muted-foreground group-hover:text-foreground",
            )}
          >
            {category || subcategory}
          </span>

          {(roles || totalRoles) && (
            <Badge
              variant="secondary"
              className={cn("text-xs ml-auto transition-all duration-200", isHovered && "scale-105 bg-primary/20")}
            >
              {roles?.length || totalRoles}
            </Badge>
          )}
        </div>
      </button>

      {hasChildren && (
        <div ref={contentRef} className="overflow-hidden transition-all duration-300 ease-out" style={{ height }}>
          <div
            className={cn(
              "py-1 transition-all duration-300",
              isExpanded ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2",
            )}
          >
            {children}
          </div>
        </div>
      )}
    </div>
  )
}
