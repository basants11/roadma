"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PopupButton } from "@/components/ui/popup-button"

interface DynamicContent {
  daily_challenge?: {
    id: string
    title: string
    description: string
    difficulty: string
    estimated_time: string
    points: number
    category: string
  }
  motivational_content?: {
    quote: string
    tip: string
    fact: string
    encouragement: string
  }
  streak_milestones?: Array<{
    target_days: number
    days_remaining: number
    title: string
    reward: string
    points: number
    progress_percentage: number
  }>
}

export function DynamicContentDisplay({ currentStreak = 0 }: { currentStreak?: number }) {
  const [content, setContent] = useState<DynamicContent | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchDynamicContent()
  }, [currentStreak])

  const fetchDynamicContent = async () => {
    try {
      setIsLoading(true)
      const response = await fetch(`/api/dynamic-content?streak=${currentStreak}`)

      if (!response.ok) {
        throw new Error("Failed to fetch dynamic content")
      }

      const data = await response.json()
      setContent(data)
    } catch (err) {
      console.error("Error fetching dynamic content:", err)
      setError("Failed to load dynamic content")
    } finally {
      setIsLoading(false)
    }
  }

  const refreshContent = async () => {
    await fetchDynamicContent()
  }

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-32 bg-muted rounded-lg"></div>
        </div>
      </div>
    )
  }

  if (error || !content) {
    return (
      <Card className="border-destructive/20">
        <CardContent className="p-6 text-center">
          <p className="text-destructive text-sm">{error || "No content available"}</p>
          <PopupButton
            onClick={refreshContent}
            variant="outline"
            size="sm"
            className="mt-2"
            popupText="Refreshing content..."
            bounceOnClick={true}
          >
            Try Again
          </PopupButton>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Daily Challenge */}
      {content.daily_challenge && (
        <Card className="bg-gradient-to-r from-blue-500/10 via-purple-500/5 to-blue-500/10 border-blue-500/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="text-lg">🎯</span>
              <span>Today's Challenge</span>
              <Badge variant="outline" className="ml-auto">
                +{content.daily_challenge.points} pts
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <h4 className="font-medium">{content.daily_challenge.title}</h4>
              <p className="text-sm text-muted-foreground mt-1">{content.daily_challenge.description}</p>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary">{content.daily_challenge.difficulty}</Badge>
                <Badge variant="outline">{content.daily_challenge.estimated_time}</Badge>
              </div>
              <PopupButton
                size="sm"
                popupText="Challenge accepted!"
                successFeedback={true}
                bounceOnClick={true}
                showRipple={true}
              >
                Accept Challenge
              </PopupButton>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Motivational Content */}
      {content.motivational_content && (
        <Card className="bg-gradient-to-r from-green-500/10 via-emerald-500/5 to-green-500/10 border-green-500/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="text-lg">✨</span>
              <span>Daily Inspiration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start space-x-3">
              <span className="text-lg mt-1 flex-shrink-0">💬</span>
              <p className="text-sm font-medium italic">"{content.motivational_content.quote}"</p>
            </div>
            <div className="flex items-start space-x-3">
              <span className="text-lg mt-1 flex-shrink-0">💡</span>
              <p className="text-sm text-muted-foreground">
                <span className="font-medium">Tip:</span> {content.motivational_content.tip}
              </p>
            </div>
            <div className="text-center">
              <PopupButton
                onClick={refreshContent}
                variant="outline"
                size="sm"
                popupText="New inspiration coming up!"
                bounceOnClick={true}
                showRipple={true}
              >
                Get New Inspiration
              </PopupButton>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Streak Milestones */}
      {content.streak_milestones && content.streak_milestones.length > 0 && (
        <Card className="bg-gradient-to-r from-orange-500/10 via-red-500/5 to-orange-500/10 border-orange-500/20">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span className="text-lg">🏆</span>
              <span>Upcoming Milestones</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {content.streak_milestones.slice(0, 2).map((milestone, index) => (
              <div key={milestone.target_days} className="p-3 rounded-lg bg-muted/30 border">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-sm">{milestone.title}</h4>
                  <Badge variant="outline" className="text-xs">
                    {milestone.days_remaining} days left
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mb-2">{milestone.reward}</p>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-orange-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${milestone.progress_percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
