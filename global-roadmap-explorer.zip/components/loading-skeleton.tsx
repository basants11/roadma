"use client"

import { cn } from "@/lib/utils"

interface LoadingSkeletonProps {
  className?: string
  lines?: number
}

export function LoadingSkeleton({ className, lines = 1 }: LoadingSkeletonProps) {
  return (
    <div className={cn("animate-pulse", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "bg-muted rounded-md",
            i === 0 ? "h-4" : "h-3",
            i > 0 && "mt-2",
            i === lines - 1 && lines > 1 && "w-3/4",
          )}
        />
      ))}
    </div>
  )
}

export function TreeLoadingSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="space-y-2">
          <LoadingSkeleton className="h-10 w-full" />
          <div className="ml-6 space-y-1">
            {Array.from({ length: 3 }).map((_, j) => (
              <LoadingSkeleton key={j} className="h-8 w-full" />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

export function RoadmapLoadingSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <LoadingSkeleton className="h-8 w-3/4" />
        <LoadingSkeleton lines={2} />
      </div>

      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="border rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between">
            <LoadingSkeleton className="h-6 w-1/2" />
            <LoadingSkeleton className="h-6 w-16" />
          </div>
          <LoadingSkeleton lines={2} />
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, j) => (
              <LoadingSkeleton key={j} className="h-10 w-full" />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
