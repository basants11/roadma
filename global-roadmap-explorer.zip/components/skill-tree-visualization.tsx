"use client"

import { useState, useMemo } from "react"
import { Card } from "@/components/ui/card"

interface SkillNode {
  id: string
  name: string
  category: string
  level: "beginner" | "intermediate" | "advanced"
  prerequisites: string[]
  description?: string
}

interface SkillTreeProps {
  skills: SkillNode[]
  onSkillSelect?: (skill: SkillNode) => void
}

export function SkillTreeVisualization({ skills, onSkillSelect }: SkillTreeProps) {
  const [expandedSkills, setExpandedSkills] = useState<Set<string>>(new Set())
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null)

  const toggleSkill = (skillId: string) => {
    setExpandedSkills((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(skillId)) {
        newSet.delete(skillId)
      } else {
        newSet.add(skillId)
      }
      return newSet
    })
  }

  // Organize skills by category and level
  const organizedSkills = useMemo(() => {
    const categories: Record<string, Record<string, SkillNode[]>> = {}

    skills.forEach((skill) => {
      if (!categories[skill.category]) {
        categories[skill.category] = {}
      }
      if (!categories[skill.category][skill.level]) {
        categories[skill.category][skill.level] = []
      }
      categories[skill.category][skill.level].push(skill)
    })

    return categories
  }, [skills])

  const getLevelColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-yellow-500/20 border-yellow-500/50 text-yellow-700 dark:text-yellow-300"
      case "intermediate":
        return "bg-amber-500/20 border-amber-500/50 text-amber-700 dark:text-amber-300"
      case "advanced":
        return "bg-orange-500/20 border-orange-500/50 text-orange-700 dark:text-orange-300"
      default:
        return "bg-gray-500/20 border-gray-500/50"
    }
  }

  const getLevelBadgeColor = (level: string) => {
    switch (level) {
      case "beginner":
        return "bg-yellow-500 text-black"
      case "intermediate":
        return "bg-amber-500 text-black"
      case "advanced":
        return "bg-orange-500 text-black"
      default:
        return "bg-gray-500 text-white"
    }
  }

  return (
    <div className="w-full space-y-8 py-8">
      <div className="space-y-2">
        <h2 className="text-2xl font-bold text-balance">Skill Tree Roadmap</h2>
        <p className="text-muted-foreground text-pretty">
          Explore the interconnected skills and their dependencies. Click on any skill to see prerequisites and related
          topics.
        </p>
      </div>

      {/* Tree visualization */}
      <div className="space-y-6">
        {Object.entries(organizedSkills).map(([category, levels]) => (
          <div key={category} className="space-y-4">
            <h3 className="text-lg font-semibold text-primary capitalize">{category}</h3>

            {/* Beginner Level */}
            {levels.beginner && (
              <div className="space-y-3 pl-4 border-l-2 border-yellow-500/30">
                <div className="text-sm font-medium text-yellow-600 dark:text-yellow-400">Beginner</div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {levels.beginner.map((skill) => (
                    <SkillCard
                      key={skill.id}
                      skill={skill}
                      isExpanded={expandedSkills.has(skill.id)}
                      isHovered={hoveredSkill === skill.id}
                      onToggle={() => toggleSkill(skill.id)}
                      onHover={(id) => setHoveredSkill(id)}
                      onSelect={() => onSkillSelect?.(skill)}
                      levelColor={getLevelColor(skill.level)}
                      badgeColor={getLevelBadgeColor(skill.level)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Intermediate Level */}
            {levels.intermediate && (
              <div className="space-y-3 pl-4 border-l-2 border-amber-500/30">
                <div className="text-sm font-medium text-amber-600 dark:text-amber-400">Intermediate</div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {levels.intermediate.map((skill) => (
                    <SkillCard
                      key={skill.id}
                      skill={skill}
                      isExpanded={expandedSkills.has(skill.id)}
                      isHovered={hoveredSkill === skill.id}
                      onToggle={() => toggleSkill(skill.id)}
                      onHover={(id) => setHoveredSkill(id)}
                      onSelect={() => onSkillSelect?.(skill)}
                      levelColor={getLevelColor(skill.level)}
                      badgeColor={getLevelBadgeColor(skill.level)}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Advanced Level */}
            {levels.advanced && (
              <div className="space-y-3 pl-4 border-l-2 border-orange-500/30">
                <div className="text-sm font-medium text-orange-600 dark:text-orange-400">Advanced</div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {levels.advanced.map((skill) => (
                    <SkillCard
                      key={skill.id}
                      skill={skill}
                      isExpanded={expandedSkills.has(skill.id)}
                      isHovered={hoveredSkill === skill.id}
                      onToggle={() => toggleSkill(skill.id)}
                      onHover={(id) => setHoveredSkill(id)}
                      onSelect={() => onSkillSelect?.(skill)}
                      levelColor={getLevelColor(skill.level)}
                      badgeColor={getLevelBadgeColor(skill.level)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}

interface SkillCardProps {
  skill: SkillNode
  isExpanded: boolean
  isHovered: boolean
  onToggle: () => void
  onHover: (id: string | null) => void
  onSelect: () => void
  levelColor: string
  badgeColor: string
}

function SkillCard({
  skill,
  isExpanded,
  isHovered,
  onToggle,
  onHover,
  onSelect,
  levelColor,
  badgeColor,
}: SkillCardProps) {
  return (
    <Card
      className={`p-4 cursor-pointer transition-all duration-300 border-2 ${levelColor} ${
        isHovered ? "shadow-lg scale-105" : ""
      } ${isExpanded ? "ring-2 ring-primary" : ""}`}
      onMouseEnter={() => onHover(skill.id)}
      onMouseLeave={() => onHover(null)}
      onClick={onToggle}
    >
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <h4 className="font-semibold text-sm leading-tight flex-1">{skill.name}</h4>
          <span className={`text-xs px-2 py-1 rounded font-medium whitespace-nowrap ${badgeColor}`}>{skill.level}</span>
        </div>

        {skill.description && <p className="text-xs text-muted-foreground line-clamp-2">{skill.description}</p>}

        {/* Prerequisites */}
        {skill.prerequisites.length > 0 && (
          <div className="pt-2 border-t border-current/20">
            <div className="text-xs font-medium mb-1 opacity-75">Prerequisites:</div>
            <div className="flex flex-wrap gap-1">
              {skill.prerequisites.map((prereq) => (
                <span key={prereq} className="text-xs bg-current/10 px-2 py-1 rounded">
                  {prereq}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Expand indicator */}
        <div className="pt-2 text-xs text-muted-foreground flex items-center gap-1">
          <span>{isExpanded ? "▼" : "▶"}</span>
          <span>{isExpanded ? "Hide" : "Show"} details</span>
        </div>
      </div>
    </Card>
  )
}
