"use client"

import { useState, useCallback, useMemo, useEffect } from "react"
import { Icons } from "@/components/icons"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import type { Role } from "@/lib/mock-data"

interface SearchFilters {
  categories: string[]
  levels: string[]
  minWeeks: number
  maxWeeks: number
  sortBy: "title" | "category" | "weeks" | "level"
  sortOrder: "asc" | "desc"
}

interface AdvancedSearchProps {
  roles: Role[]
  onFilteredRoles: (roles: Role[]) => void
  searchQuery: string
  onSearchQueryChange: (query: string) => void
}

export function AdvancedSearch({ roles, onFilteredRoles, searchQuery, onSearchQueryChange }: AdvancedSearchProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    categories: [],
    levels: [],
    minWeeks: 1,
    maxWeeks: 52,
    sortBy: "title",
    sortOrder: "asc",
  })
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)

  // Extract unique values for filter options
  const filterOptions = useMemo(() => {
    const categories = Array.from(new Set(roles.map((role) => role.category))).sort()
    const levels = Array.from(new Set(roles.map((role) => role.level))).sort()
    const weekRange = {
      min: Math.min(...roles.map((role) => role.estimatedWeeks)),
      max: Math.max(...roles.map((role) => role.estimatedWeeks)),
    }

    return { categories, levels, weekRange }
  }, [roles])

  // Apply filters and search
  const filteredRoles = useMemo(() => {
    const filtered = roles.filter((role) => {
      // Text search
      const searchLower = searchQuery.toLowerCase()
      const matchesSearch =
        !searchQuery ||
        role.title.toLowerCase().includes(searchLower) ||
        role.category.toLowerCase().includes(searchLower) ||
        role.description.toLowerCase().includes(searchLower)

      // Category filter
      const matchesCategory = filters.categories.length === 0 || filters.categories.includes(role.category)

      // Level filter
      const matchesLevel = filters.levels.length === 0 || filters.levels.includes(role.level)

      // Week range filter
      const matchesWeeks = role.estimatedWeeks >= filters.minWeeks && role.estimatedWeeks <= filters.maxWeeks

      return matchesSearch && matchesCategory && matchesLevel && matchesWeeks
    })

    // Apply sorting
    filtered.sort((a, b) => {
      let comparison = 0

      switch (filters.sortBy) {
        case "title":
          comparison = a.title.localeCompare(b.title)
          break
        case "category":
          comparison = a.category.localeCompare(b.category)
          break
        case "weeks":
          comparison = a.estimatedWeeks - b.estimatedWeeks
          break
        case "level":
          const levelOrder = { Beginner: 1, Intermediate: 2, Advanced: 3, Expert: 4 }
          comparison =
            (levelOrder[a.level as keyof typeof levelOrder] || 0) -
            (levelOrder[b.level as keyof typeof levelOrder] || 0)
          break
      }

      return filters.sortOrder === "desc" ? -comparison : comparison
    })

    return filtered
  }, [roles, searchQuery, filters])

  // This prevents the "Cannot update a component while rendering a different component" error
  useEffect(() => {
    onFilteredRoles(filteredRoles)
  }, [filteredRoles, onFilteredRoles])

  const updateFilter = useCallback(<K extends keyof SearchFilters>(key: K, value: SearchFilters[K]) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }, [])

  const toggleCategory = useCallback((category: string) => {
    setFilters((prev) => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter((c) => c !== category)
        : [...prev.categories, category],
    }))
  }, [])

  const toggleLevel = useCallback((level: string) => {
    setFilters((prev) => ({
      ...prev,
      levels: prev.levels.includes(level) ? prev.levels.filter((l) => l !== level) : [...prev.levels, level],
    }))
  }, [])

  const clearFilters = useCallback(() => {
    setFilters({
      categories: [],
      levels: [],
      minWeeks: filterOptions.weekRange.min,
      maxWeeks: filterOptions.weekRange.max,
      sortBy: "title",
      sortOrder: "asc",
    })
    onSearchQueryChange("")
  }, [filterOptions.weekRange, onSearchQueryChange])

  const activeFiltersCount = filters.categories.length + filters.levels.length + (searchQuery ? 1 : 0)

  return (
    <div className="space-y-3">
      {/* Search Input */}
      <div className="relative">
        <Icons.Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Search roles, categories, or skills..."
          value={searchQuery}
          onChange={(e) => onSearchQueryChange(e.target.value)}
          className="pl-10 pr-10"
        />
        {searchQuery && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onSearchQueryChange("")}
            className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8 p-0"
          >
            <Icons.X className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center justify-between">
        <Popover open={isFiltersOpen} onOpenChange={setIsFiltersOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="relative bg-transparent">
              <Icons.SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge variant="secondary" className="ml-2 h-5 w-5 p-0 text-xs">
                  {activeFiltersCount}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-4" align="start">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Advanced Filters</h4>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  Clear All
                </Button>
              </div>

              {/* Categories */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Categories</label>
                <div className="grid grid-cols-2 gap-2">
                  {filterOptions.categories.map((category) => (
                    <div key={category} className="flex items-center space-x-2">
                      <Checkbox
                        id={`category-${category}`}
                        checked={filters.categories.includes(category)}
                        onCheckedChange={() => toggleCategory(category)}
                      />
                      <label htmlFor={`category-${category}`} className="text-xs cursor-pointer truncate">
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Levels */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Experience Level</label>
                <div className="flex flex-wrap gap-2">
                  {filterOptions.levels.map((level) => (
                    <div key={level} className="flex items-center space-x-2">
                      <Checkbox
                        id={`level-${level}`}
                        checked={filters.levels.includes(level)}
                        onCheckedChange={() => toggleLevel(level)}
                      />
                      <label htmlFor={`level-${level}`} className="text-xs cursor-pointer">
                        {level}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Week Range */}
              <div className="space-y-2">
                <label className="text-sm font-medium">
                  Learning Time: {filters.minWeeks}-{filters.maxWeeks} weeks
                </label>
                <Slider
                  value={[filters.minWeeks, filters.maxWeeks]}
                  onValueChange={([min, max]) => {
                    updateFilter("minWeeks", min)
                    updateFilter("maxWeeks", max)
                  }}
                  min={filterOptions.weekRange.min}
                  max={filterOptions.weekRange.max}
                  step={1}
                  className="w-full"
                />
              </div>

              {/* Sorting */}
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Sort By</label>
                  <Select value={filters.sortBy} onValueChange={(value: any) => updateFilter("sortBy", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="title">Title</SelectItem>
                      <SelectItem value="category">Category</SelectItem>
                      <SelectItem value="weeks">Duration</SelectItem>
                      <SelectItem value="level">Level</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Order</label>
                  <Select value={filters.sortOrder} onValueChange={(value: any) => updateFilter("sortOrder", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="asc">Ascending</SelectItem>
                      <SelectItem value="desc">Descending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>

        <div className="text-xs text-muted-foreground">
          {filteredRoles.length} of {roles.length} roles
        </div>
      </div>

      {/* Active Filters */}
      {(filters.categories.length > 0 || filters.levels.length > 0 || searchQuery) && (
        <div className="flex flex-wrap gap-1">
          {searchQuery && (
            <Badge variant="secondary" className="text-xs">
              Search: {searchQuery}
              <Button variant="ghost" size="sm" onClick={() => onSearchQueryChange("")} className="ml-1 h-4 w-4 p-0">
                <Icons.X className="w-3 h-3" />
              </Button>
            </Badge>
          )}
          {filters.categories.map((category) => (
            <Badge key={category} variant="secondary" className="text-xs">
              {category}
              <Button variant="ghost" size="sm" onClick={() => toggleCategory(category)} className="ml-1 h-4 w-4 p-0">
                <Icons.X className="w-3 h-3" />
              </Button>
            </Badge>
          ))}
          {filters.levels.map((level) => (
            <Badge key={level} variant="secondary" className="text-xs">
              {level}
              <Button variant="ghost" size="sm" onClick={() => toggleLevel(level)} className="ml-1 h-4 w-4 p-0">
                <Icons.X className="w-3 h-3" />
              </Button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  )
}
