"use client"
import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { PopupButton } from "@/components/ui/popup-button"
import { TooltipHelper, TooltipProvider } from "@/components/ui/tooltip-helper"
import { OnboardingFlow } from "@/components/onboarding-flow"
import { Icons } from "@/components/icons"
import { Target, Sparkles, ArrowRight, Users, TrendingUp, BookOpen, Zap } from "lucide-react"

interface WelcomeHeroProps {
  onGetStarted?: (userData: Record<string, string>) => void
}

export function WelcomeHero({ onGetStarted }: WelcomeHeroProps) {
  const [showOnboarding, setShowOnboarding] = useState(false)
  const [isFirstVisit, setIsFirstVisit] = useState(true)

  useEffect(() => {
    const hasVisited = localStorage.getItem("hasVisited")
    setIsFirstVisit(!hasVisited)
  }, [])

  const handleGetStarted = () => {
    setShowOnboarding(true)
  }

  const handleOnboardingComplete = (userData: Record<string, string>) => {
    localStorage.setItem("hasVisited", "true")
    localStorage.setItem("userProfile", JSON.stringify(userData))
    setShowOnboarding(false)
    setIsFirstVisit(false)
    onGetStarted?.(userData)
  }

  const handleSkipOnboarding = () => {
    localStorage.setItem("hasVisited", "true")
    setShowOnboarding(false)
    setIsFirstVisit(false)
  }

  return (
    <>
      <TooltipProvider>
        <section
          className="flex flex-col items-center justify-center min-h-[85vh] p-4 md:p-6 space-y-10"
          aria-label="Welcome to Global Roadmap Explorer"
        >
          <div className="text-center max-w-5xl space-y-8">
            {/* Hero Icon */}
            <div
              className="w-20 h-20 md:w-24 md:h-24 mx-auto mb-8 rounded-2xl bg-gradient-to-br from-primary/30 via-accent/20 to-primary/30 flex items-center justify-center backdrop-blur-sm border border-primary/30 shadow-2xl hover:shadow-primary/40 transition-all duration-500 hover:scale-110 hover:rotate-3 glow-on-hover relative"
              role="img"
              aria-label="Target icon representing goal achievement"
            >
              <Icons.Target className="w-10 h-10 md:w-12 md:h-12 text-primary animate-pulse" />
              <div className="absolute -top-2 -right-2 w-4 h-4 bg-primary/60 rounded-full animate-ping" />
              <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-accent/60 rounded-full animate-pulse delay-300" />
            </div>

            {/* Hero Copy */}
            <div className="space-y-6">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">
                  <Sparkles className="w-3 h-3 mr-1" />
                  AI-Powered Career Guidance
                </Badge>
                {isFirstVisit && (
                  <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20 animate-pulse">
                    <Zap className="w-3 h-3 mr-1" />
                    New User
                  </Badge>
                )}
              </div>

              <h1 className="text-4xl md:text-6xl font-bold text-balance bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent leading-tight">
                Find Your Path
              </h1>

              <p className="text-xl md:text-2xl text-muted-foreground text-pretty leading-relaxed max-w-3xl mx-auto font-medium">
                Get personalized roadmaps and track progress with{" "}
                <span className="text-primary font-semibold">smart guidance</span>
              </p>

              <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-1">
                  <BookOpen className="w-4 h-4" />
                  <span>Learn at your pace</span>
                </div>
                <div className="w-1 h-1 bg-muted-foreground/50 rounded-full" />
                <div className="flex items-center gap-1">
                  <Target className="w-4 h-4" />
                  <span>Track your goals</span>
                </div>
                <div className="w-1 h-1 bg-muted-foreground/50 rounded-full" />
                <div className="flex items-center gap-1">
                  <TrendingUp className="w-4 h-4" />
                  <span>See real progress</span>
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-6">
              <PopupButton
                size="lg"
                onClick={handleGetStarted}
                className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 px-8 py-4 text-lg font-semibold shadow-lg hover:shadow-primary/30"
                popupText="Starting your journey..."
                successFeedback={true}
                glowEffect={true}
                bounceOnClick={true}
              >
                <span>Get Started</span>
                <ArrowRight className="w-5 h-5 ml-2 transition-transform group-hover:translate-x-1" />
              </PopupButton>

              <div className="flex items-center gap-2">
                <PopupButton variant="outline" size="lg" className="px-6 py-4 text-lg" popupText="Exploring careers...">
                  <span>Browse Careers</span>
                </PopupButton>
                <TooltipHelper content="Explore 50+ career paths without signing up" type="info" />
              </div>
            </div>

            {/* Social Proof Stats */}
            <div
              className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto pt-8"
              role="region"
              aria-label="Platform statistics"
            >
              <div className="text-center p-4 rounded-xl bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm border border-border/50 hover:border-primary/40 transition-all duration-500 hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
                <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-1">
                  50+
                </div>
                <div className="text-xs text-muted-foreground font-medium">Career Paths</div>
              </div>

              <div className="text-center p-4 rounded-xl bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm border border-border/50 hover:border-primary/40 transition-all duration-500 hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
                <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-1">
                  AI
                </div>
                <div className="text-xs text-muted-foreground font-medium">Smart Guidance</div>
              </div>

              <div className="text-center p-4 rounded-xl bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm border border-border/50 hover:border-primary/40 transition-all duration-500 hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
                <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-1 flex items-center justify-center gap-1">
                  <Users className="w-5 h-5" />
                  1K+
                </div>
                <div className="text-xs text-muted-foreground font-medium">Active Learners</div>
              </div>

              <div className="text-center p-4 rounded-xl bg-gradient-to-br from-card/80 to-card/60 backdrop-blur-sm border border-border/50 hover:border-primary/40 transition-all duration-500 hover:scale-105 hover:-translate-y-1 shadow-lg hover:shadow-primary/20">
                <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent mb-1">
                  Free
                </div>
                <div className="text-xs text-muted-foreground font-medium">Always</div>
              </div>
            </div>
          </div>
        </section>
      </TooltipProvider>

      {showOnboarding && <OnboardingFlow onComplete={handleOnboardingComplete} onSkip={handleSkipOnboarding} />}
    </>
  )
}
