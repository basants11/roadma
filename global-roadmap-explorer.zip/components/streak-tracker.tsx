"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { PopupButton } from "@/components/ui/popup-button"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import { Flame, Target, CheckCircle2, BookOpen, Send, Calendar } from "lucide-react"

interface StreakData {
  currentStreak: number
  longestStreak: number
  totalDays: number
  lastVisit: string
  todayCompleted: boolean
  weeklyGoal: number
  weeklyProgress: number
  learningEntries: LearningEntry[]
}

interface LearningEntry {
  id: string
  date: string
  content: string
  timestamp: number
}

interface DailyTask {
  id: string
  title: string
  completed: boolean
  points: number
}

export function StreakTracker() {
  const [streakData, setStreakData] = useState<StreakData>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("streakData")
      if (saved) {
        try {
          const parsed = JSON.parse(saved)
          return {
            ...parsed,
            learningEntries: Array.isArray(parsed.learningEntries) ? parsed.learningEntries : [],
          }
        } catch (error) {
          console.log("[v0] Error parsing saved streak data:", error)
        }
      }
    }
    return {
      currentStreak: 0,
      longestStreak: 0,
      totalDays: 0,
      lastVisit: new Date().toISOString().split("T")[0],
      todayCompleted: false,
      weeklyGoal: 5,
      weeklyProgress: 0,
      learningEntries: [],
    }
  })

  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([
    { id: "1", title: "Explore a new career roadmap", completed: false, points: 10 },
    { id: "2", title: "Complete a learning milestone", completed: false, points: 20 },
    { id: "3", title: "Use AI search for guidance", completed: false, points: 5 },
  ])

  const [learningInput, setLearningInput] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    const today = new Date().toISOString().split("T")[0]
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0]

    if (streakData.lastVisit !== today) {
      if (streakData.lastVisit === yesterday && streakData.todayCompleted) {
        // Continue streak from yesterday
        setStreakData((prev) => ({
          ...prev,
          lastVisit: today,
          todayCompleted: false,
        }))
      } else if (streakData.lastVisit !== yesterday) {
        // Streak broken - reset to 0
        setStreakData((prev) => ({
          ...prev,
          currentStreak: 0,
          lastVisit: today,
          todayCompleted: false,
          weeklyProgress: 0,
        }))
      }
    }
  }, [streakData.lastVisit, streakData.todayCompleted])

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("streakData", JSON.stringify(streakData))
    }
  }, [streakData])

  const completeTask = (taskId: string) => {
    setDailyTasks((prev) => prev.map((task) => (task.id === taskId ? { ...task, completed: true } : task)))

    const completedTasks = dailyTasks.filter((task) => task.completed || task.id === taskId).length
    const allTasksCompleted = completedTasks === dailyTasks.length

    if (allTasksCompleted && !streakData.todayCompleted) {
      setStreakData((prev) => ({
        ...prev,
        currentStreak: prev.currentStreak + 1,
        longestStreak: Math.max(prev.longestStreak, prev.currentStreak + 1),
        totalDays: prev.totalDays + 1,
        todayCompleted: true,
        weeklyProgress: Math.min(prev.weeklyProgress + 1, prev.weeklyGoal),
      }))
    }
  }

  const submitLearning = async () => {
    if (!learningInput.trim()) return

    setIsSubmitting(true)

    const today = new Date().toISOString().split("T")[0]
    const hasLearningToday =
      Array.isArray(streakData.learningEntries) && streakData.learningEntries.some((entry) => entry.date === today)

    // Add learning entry
    const newEntry: LearningEntry = {
      id: Date.now().toString(),
      date: today,
      content: learningInput.trim(),
      timestamp: Date.now(),
    }

    setStreakData((prev) => {
      const currentEntries = Array.isArray(prev.learningEntries) ? prev.learningEntries : []

      const updatedData = {
        ...prev,
        learningEntries: [...currentEntries, newEntry],
      }

      // If this is the first learning entry today, increment streak
      if (!hasLearningToday && !prev.todayCompleted) {
        updatedData.currentStreak = prev.currentStreak + 1
        updatedData.longestStreak = Math.max(prev.longestStreak, prev.currentStreak + 1)
        updatedData.totalDays = prev.totalDays + 1
        updatedData.todayCompleted = true
        updatedData.weeklyProgress = Math.min(prev.weeklyProgress + 1, prev.weeklyGoal)
        updatedData.lastVisit = today
      }

      return updatedData
    })

    setLearningInput("")
    setIsSubmitting(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault()
      submitLearning()
    }
  }

  const resetStreak = () => {
    setStreakData((prev) => ({
      ...prev,
      currentStreak: 0,
      weeklyProgress: 0,
    }))
    setDailyTasks((prev) => prev.map((task) => ({ ...task, completed: false })))
  }

  const completedTasks = dailyTasks.filter((task) => task.completed).length
  const totalPoints = dailyTasks.filter((task) => task.completed).reduce((sum, task) => sum + task.points, 0)

  const today = new Date().toISOString().split("T")[0]
  const hasLearningToday =
    Array.isArray(streakData.learningEntries) && streakData.learningEntries.some((entry) => entry.date === today)

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-orange-500/10 via-red-500/5 to-orange-500/10 border-orange-500/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Flame className="h-5 w-5 text-orange-500" />
            <span>Learning Streak</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-500">{streakData.currentStreak}</div>
              <div className="text-sm text-muted-foreground">Current Streak</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-primary">{streakData.longestStreak}</div>
              <div className="text-sm text-muted-foreground">Longest Streak</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">{streakData.totalDays}</div>
              <div className="text-sm text-muted-foreground">Total Days</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-500">{totalPoints}</div>
              <div className="text-sm text-muted-foreground">Today's Points</div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span>Weekly Goal Progress</span>
                <span>
                  {streakData.weeklyProgress}/{streakData.weeklyGoal} days
                </span>
              </div>
              <Progress value={(streakData.weeklyProgress / streakData.weeklyGoal) * 100} className="h-2" />
            </div>

            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium flex items-center space-x-2">
                  <BookOpen className="h-4 w-4" />
                  <span>Daily Learning Log</span>
                </h4>
                <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  <span>{new Date().toLocaleDateString()}</span>
                </div>
              </div>

              {hasLearningToday ? (
                <div className="space-y-3">
                  <Badge
                    variant="secondary"
                    className="w-full justify-center py-3 bg-green-500/20 text-green-700 border-green-500/30"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Learning logged for today! Streak maintained 🎉
                  </Badge>
                  {Array.isArray(streakData.learningEntries) &&
                    streakData.learningEntries
                      .filter((entry) => entry.date === today)
                      .map((entry) => (
                        <div key={entry.id} className="p-3 rounded-lg bg-green-50 border border-green-200">
                          <div className="text-sm font-medium text-green-800 mb-1">Today's Learning:</div>
                          <div className="text-sm text-green-700">{entry.content}</div>
                        </div>
                      ))}
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-4 rounded-lg bg-muted/30 border-2 border-dashed border-muted-foreground/30">
                    <p className="text-sm text-muted-foreground mb-3">
                      Share what you learned today to maintain your streak. This could be anything - a new skill,
                      insight, or knowledge you gained.
                    </p>
                    <Textarea
                      placeholder="Example: Learned about React hooks, discovered a new productivity technique, understood a complex concept..."
                      value={learningInput}
                      onChange={(e) => setLearningInput(e.target.value)}
                      onKeyDown={handleKeyDown}
                      className="min-h-[100px] resize-none border-0 bg-background focus-visible:ring-1"
                    />
                    <div className="flex items-center justify-between mt-3">
                      <div className="text-xs text-muted-foreground">Tip: Press Ctrl+Enter to submit quickly</div>
                      <div className="text-xs text-muted-foreground">{learningInput.length}/500 characters</div>
                    </div>
                  </div>
                  <PopupButton
                    onClick={submitLearning}
                    disabled={!learningInput.trim() || isSubmitting || learningInput.length > 500}
                    className="w-full py-3"
                    size="lg"
                    successFeedback={true}
                    popupText="Great job! Streak continued!"
                    glowEffect={true}
                    bounceOnClick={true}
                    showRipple={true}
                  >
                    <Send className="h-4 w-4 mr-2" />
                    {isSubmitting ? "Submitting..." : "Submit Learning & Continue Streak"}
                  </PopupButton>
                </div>
              )}
            </div>

            {!hasLearningToday && !streakData.todayCompleted && (
              <div className="space-y-3 border-t pt-4">
                <h4 className="font-medium flex items-center space-x-2">
                  <Target className="h-4 w-4" />
                  <span>
                    Alternative: Complete Daily Tasks ({completedTasks}/{dailyTasks.length})
                  </span>
                </h4>
                <p className="text-xs text-muted-foreground mb-3">
                  Or maintain your streak by completing these daily tasks instead
                </p>
                {dailyTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border">
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-4 h-4 rounded-full border-2 ${
                          task.completed
                            ? "bg-green-500 border-green-500"
                            : "border-muted-foreground hover:border-primary"
                        }`}
                      />
                      <span className={task.completed ? "line-through text-muted-foreground" : ""}>{task.title}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-xs">
                        +{task.points} pts
                      </Badge>
                      {!task.completed && (
                        <PopupButton
                          size="sm"
                          variant="outline"
                          onClick={() => completeTask(task.id)}
                          popupText={`+${task.points} points earned!`}
                          successFeedback={true}
                          bounceOnClick={true}
                          showRipple={true}
                        >
                          Complete
                        </PopupButton>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {Array.isArray(streakData.learningEntries) && streakData.learningEntries.length > 0 && (
              <div className="space-y-3 border-t pt-4">
                <h4 className="font-medium text-sm text-muted-foreground">Recent Learning History</h4>
                <div className="space-y-2 max-h-40 overflow-y-auto">
                  {streakData.learningEntries
                    .slice(-5)
                    .reverse()
                    .map((entry) => (
                      <div key={entry.id} className="text-sm p-3 rounded-lg bg-muted/30 border">
                        <div className="flex items-center justify-between mb-2">
                          <div className="text-xs font-medium text-muted-foreground">{entry.date}</div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(entry.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                        <div className="text-foreground leading-relaxed">{entry.content}</div>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
