"use client"

import { useState, useCallback } from "react"
import { Icons } from "@/components/icons"
import { PopupButton } from "@/components/ui/popup-button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { RoadmapLoadingSkeleton } from "./loading-skeleton"
import { cn } from "@/lib/utils"
import { type Role, type RoadmapNode, generateRoadmapNodes } from "@/lib/mock-data"
import { SkillTreeVisualization } from "@/components/skill-tree-visualization"

interface RoadmapGeneratorProps {
  role: Role
  onRoadmapGenerated?: (roadmap: RoadmapNode[]) => void
}

type TimeFrame = "12-week" | "6-month" | "1-year"

interface GeneratedRoadmap {
  timeFrame: TimeFrame
  nodes: RoadmapNode[]
  totalWeeks: number
  completedSteps: number
}

export function RoadmapGenerator({ role, onRoadmapGenerated }: RoadmapGeneratorProps) {
  const [selectedTimeFrame, setSelectedTimeFrame] = useState<TimeFrame>("6-month")
  const [generatedRoadmap, setGeneratedRoadmap] = useState<GeneratedRoadmap | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [completedSteps, setCompletedSteps] = useState<Set<string>>(new Set())
  const [animatingSteps, setAnimatingSteps] = useState<Set<string>>(new Set())

  const timeFrameOptions = {
    "12-week": {
      label: "12 Week Sprint",
      weeks: 12,
      description: "Intensive bootcamp-style learning",
      icon: Icons.Zap,
    },
    "6-month": {
      label: "6 Month Journey",
      weeks: 24,
      description: "Balanced learning with practice",
      icon: Icons.Target,
    },
    "1-year": {
      label: "1 Year Mastery",
      weeks: 52,
      description: "Comprehensive deep-dive approach",
      icon: Icons.Trophy,
    },
  }

  const generateRoadmap = useCallback(async () => {
    setIsGenerating(true)

    // Simulate API call with realistic delay
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const baseNodes = generateRoadmapNodes(role.id)
    const targetWeeks = timeFrameOptions[selectedTimeFrame].weeks

    // Adjust roadmap based on timeframe
    const adjustedNodes = baseNodes.map((node) => {
      const adjustmentFactor = selectedTimeFrame === "12-week" ? 0.6 : selectedTimeFrame === "6-month" ? 1.0 : 1.4

      return {
        ...node,
        estimatedWeeks: Math.max(1, Math.round(node.estimatedWeeks * adjustmentFactor)),
        children: node.children?.map((child) => ({
          ...child,
          estimatedWeeks: Math.max(1, Math.round(child.estimatedWeeks * adjustmentFactor)),
        })),
      }
    })

    const totalWeeks = adjustedNodes.reduce((sum, node) => sum + node.estimatedWeeks, 0)

    const roadmap: GeneratedRoadmap = {
      timeFrame: selectedTimeFrame,
      nodes: adjustedNodes,
      totalWeeks,
      completedSteps: 0,
    }

    setGeneratedRoadmap(roadmap)
    setIsGenerating(false)
    onRoadmapGenerated?.(adjustedNodes)
  }, [role.id, selectedTimeFrame, onRoadmapGenerated])

  const toggleStepCompletion = useCallback((stepId: string) => {
    // Add animation state
    setAnimatingSteps((prev) => new Set(prev).add(stepId))

    setTimeout(() => {
      setCompletedSteps((prev) => {
        const newSet = new Set(prev)
        if (newSet.has(stepId)) {
          newSet.delete(stepId)
        } else {
          newSet.add(stepId)
        }
        return newSet
      })

      // Remove animation state after completion
      setTimeout(() => {
        setAnimatingSteps((prev) => {
          const newSet = new Set(prev)
          newSet.delete(stepId)
          return newSet
        })
      }, 300)
    }, 150)
  }, [])

  const calculateProgress = useCallback(() => {
    if (!generatedRoadmap) return 0

    const totalSteps = generatedRoadmap.nodes.reduce((sum, node) => sum + 1 + (node.children?.length || 0), 0)

    return totalSteps > 0 ? (completedSteps.size / totalSteps) * 100 : 0
  }, [generatedRoadmap, completedSteps])

  const getProgressStats = useCallback(() => {
    if (!generatedRoadmap) return { completed: 0, total: 0, weeks: 0 }

    const totalSteps = generatedRoadmap.nodes.reduce((sum, node) => sum + 1 + (node.children?.length || 0), 0)

    const completedWeeks = generatedRoadmap.nodes.reduce((sum, node) => {
      let nodeWeeks = 0
      if (completedSteps.has(node.id)) {
        nodeWeeks += node.estimatedWeeks
      }
      if (node.children) {
        nodeWeeks += node.children.reduce(
          (childSum, child) => childSum + (completedSteps.has(child.id) ? child.estimatedWeeks : 0),
          0,
        )
      }
      return sum + nodeWeeks
    }, 0)

    return {
      completed: completedSteps.size,
      total: totalSteps,
      weeks: completedWeeks,
    }
  }, [generatedRoadmap, completedSteps])

  const progress = calculateProgress()
  const stats = getProgressStats()

  function getSkillsForRole(roleId: string) {
    const skillsByRole: Record<string, any[]> = {
      "frontend-dev": [
        {
          id: "html-css",
          name: "HTML & CSS",
          category: "Frontend Fundamentals",
          level: "beginner",
          prerequisites: [],
          description: "Master semantic HTML and modern CSS layouts",
        },
        {
          id: "javascript-basics",
          name: "JavaScript Basics",
          category: "Frontend Fundamentals",
          level: "beginner",
          prerequisites: ["html-css"],
          description: "Learn JavaScript fundamentals and DOM manipulation",
        },
        {
          id: "react",
          name: "React",
          category: "Frontend Frameworks",
          level: "intermediate",
          prerequisites: ["javascript-basics"],
          description: "Build interactive UIs with React",
        },
        {
          id: "state-management",
          name: "State Management",
          category: "Frontend Frameworks",
          level: "intermediate",
          prerequisites: ["react"],
          description: "Master Redux, Context API, or Zustand",
        },
        {
          id: "typescript",
          name: "TypeScript",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["javascript-basics"],
          description: "Add type safety to your JavaScript projects",
        },
        {
          id: "testing",
          name: "Testing & QA",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["react"],
          description: "Write unit and integration tests",
        },
      ],
      "backend-dev": [
        {
          id: "programming-basics",
          name: "Programming Basics",
          category: "Fundamentals",
          level: "beginner",
          prerequisites: [],
          description: "Learn core programming concepts",
        },
        {
          id: "databases",
          name: "Databases",
          category: "Backend Fundamentals",
          level: "beginner",
          prerequisites: ["programming-basics"],
          description: "Understand SQL and database design",
        },
        {
          id: "apis",
          name: "REST APIs",
          category: "Backend Fundamentals",
          level: "intermediate",
          prerequisites: ["programming-basics"],
          description: "Design and build RESTful APIs",
        },
        {
          id: "authentication",
          name: "Authentication & Security",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["apis"],
          description: "Implement secure authentication systems",
        },
        {
          id: "microservices",
          name: "Microservices",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["apis"],
          description: "Build scalable microservice architectures",
        },
        {
          id: "devops",
          name: "DevOps & Deployment",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["databases"],
          description: "Deploy and manage applications",
        },
      ],
      "fullstack-dev": [
        {
          id: "frontend-basics",
          name: "Frontend Basics",
          category: "Frontend",
          level: "beginner",
          prerequisites: [],
          description: "HTML, CSS, and JavaScript fundamentals",
        },
        {
          id: "backend-basics",
          name: "Backend Basics",
          category: "Backend",
          level: "beginner",
          prerequisites: [],
          description: "Server-side programming and databases",
        },
        {
          id: "fullstack-framework",
          name: "Full-Stack Framework",
          category: "Integration",
          level: "intermediate",
          prerequisites: ["frontend-basics", "backend-basics"],
          description: "Learn Next.js, Django, or similar",
        },
        {
          id: "deployment",
          name: "Deployment & DevOps",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["fullstack-framework"],
          description: "Deploy full-stack applications",
        },
        {
          id: "performance",
          name: "Performance Optimization",
          category: "Advanced Skills",
          level: "advanced",
          prerequisites: ["fullstack-framework"],
          description: "Optimize frontend and backend performance",
        },
      ],
    }

    return skillsByRole[roleId] || skillsByRole["frontend-dev"]
  }

  if (isGenerating) {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span>Generating Your Personalized Roadmap...</span>
            </CardTitle>
            <CardDescription>
              Analyzing {role.title} requirements and creating your optimal learning path.
            </CardDescription>
          </CardHeader>
        </Card>
        <RoadmapLoadingSkeleton />
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Generator Controls */}
      <Card className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <CardHeader className="pb-4 relative">
          <CardTitle className="flex items-center space-x-2 text-lg md:text-xl">
            <Icons.Sparkles className="w-4 h-4 md:w-5 md:h-5 text-primary animate-pulse" />
            <span>Personal Roadmap Generator</span>
          </CardTitle>
          <CardDescription className="text-sm">
            Create a customized learning path for {role.title} based on your preferred timeline.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 relative">
          <div className="space-y-2">
            <label className="text-sm font-medium">Choose your learning timeline:</label>
            <Select value={selectedTimeFrame} onValueChange={(value: TimeFrame) => setSelectedTimeFrame(value)}>
              <SelectTrigger className="transition-all duration-200 hover:border-primary/50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(timeFrameOptions).map(([key, option]) => {
                  const Icon = option.icon
                  return (
                    <SelectItem key={key} value={key}>
                      <div className="flex items-center space-x-2">
                        <Icon className="w-4 h-4" />
                        <div className="flex flex-col">
                          <span className="font-medium">{option.label}</span>
                          <span className="text-xs text-muted-foreground hidden md:block">{option.description}</span>
                        </div>
                      </div>
                    </SelectItem>
                  )
                })}
              </SelectContent>
            </Select>
          </div>

          <PopupButton
            onClick={generateRoadmap}
            disabled={isGenerating}
            size="lg"
            className="w-full relative overflow-hidden group"
            popupText="Generating your personalized roadmap!"
            successFeedback={true}
            glowEffect={true}
            bounceOnClick={true}
            showRipple={true}
          >
            <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary/80 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="relative flex items-center">
              <Icons.Target className="w-4 h-4 mr-2 transition-transform group-hover:scale-110" />
              Generate {timeFrameOptions[selectedTimeFrame].label}
            </div>
          </PopupButton>
        </CardContent>
      </Card>

      {/* Generated Roadmap */}
      {generatedRoadmap && (
        <div className="space-y-4 md:space-y-6 animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
          {/* Progress Overview */}
          <Card className="relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 via-transparent to-blue-500/5" />
            <CardHeader className="pb-4 relative">
              <CardTitle className="flex items-center justify-between text-lg">
                <span>Your Learning Progress</span>
                <Badge variant="outline" className="text-xs animate-pulse">
                  {Math.round(progress)}% Complete
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 relative">
              <Progress value={progress} className="h-3 transition-all duration-500" />
              <div className="grid grid-cols-3 gap-2 md:gap-4 text-center">
                <div className="transition-all duration-300 hover:scale-105">
                  <div className="text-lg md:text-2xl font-bold text-primary transition-all duration-300">
                    {stats.completed}
                  </div>
                  <div className="text-xs text-muted-foreground">Steps Completed</div>
                </div>
                <div className="transition-all duration-300 hover:scale-105">
                  <div className="text-lg md:text-2xl font-bold">{stats.total}</div>
                  <div className="text-xs text-muted-foreground">Total Steps</div>
                </div>
                <div className="transition-all duration-300 hover:scale-105">
                  <div className="text-lg md:text-2xl font-bold text-green-500">{stats.weeks}</div>
                  <div className="text-xs text-muted-foreground">Weeks Saved</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Roadmap Timeline */}
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
              <h3 className="text-xl md:text-2xl font-bold text-balance">
                Your {timeFrameOptions[generatedRoadmap.timeFrame].label} Roadmap
              </h3>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Icons.Calendar className="w-4 h-4" />
                <span>{generatedRoadmap.totalWeeks} weeks total</span>
              </div>
            </div>

            <div className="space-y-3 md:space-y-4">
              {generatedRoadmap.nodes.map((node, index) => {
                const isNodeCompleted = completedSteps.has(node.id)
                const isNodeAnimating = animatingSteps.has(node.id)
                const completedChildren = node.children?.filter((child) => completedSteps.has(child.id)).length || 0
                const totalChildren = node.children?.length || 0

                return (
                  <Card
                    key={node.id}
                    className={cn(
                      "relative transition-all duration-300 hover:shadow-md",
                      isNodeCompleted && "bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800",
                      isNodeAnimating && "scale-[1.02]",
                    )}
                    style={{
                      animationDelay: `${index * 100}ms`,
                    }}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start md:items-center justify-between gap-3">
                        <div className="flex items-start md:items-center space-x-3 flex-1 min-w-0">
                          <button
                            onClick={() => toggleStepCompletion(node.id)}
                            className={cn(
                              "flex items-center justify-center w-6 h-6 md:w-8 md:h-8 rounded-full border-2 transition-all duration-300 flex-shrink-0 mt-1 md:mt-0",
                              "hover:scale-110 active:scale-95",
                              isNodeAnimating && "animate-pulse scale-110",
                            )}
                          >
                            {isNodeCompleted ? (
                              <Icons.CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-green-500 animate-in zoom-in-50 duration-300" />
                            ) : (
                              <div className="w-5 h-5 md:w-6 md:h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs md:text-sm font-bold transition-all duration-200 hover:bg-primary/80">
                                {index + 1}
                              </div>
                            )}
                          </button>
                          <div className="flex-1 min-w-0">
                            <CardTitle
                              className={cn(
                                "text-base md:text-lg transition-all duration-300",
                                isNodeCompleted && "line-through text-muted-foreground",
                              )}
                            >
                              {node.title}
                            </CardTitle>
                            {totalChildren > 0 && (
                              <div className="text-xs md:text-sm text-muted-foreground mt-1">
                                <div className="flex items-center space-x-2">
                                  <span>
                                    {completedChildren}/{totalChildren} skills completed
                                  </span>
                                  {completedChildren > 0 && (
                                    <div className="w-16 bg-muted rounded-full h-1">
                                      <div
                                        className="bg-green-500 h-1 rounded-full transition-all duration-500"
                                        style={{ width: `${(completedChildren / totalChildren) * 100}%` }}
                                      />
                                    </div>
                                  )}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col md:flex-row items-end md:items-center space-y-1 md:space-y-0 md:space-x-2 flex-shrink-0">
                          <Badge
                            variant="outline"
                            className="flex items-center space-x-1 text-xs transition-all duration-200 hover:scale-105"
                          >
                            <Icons.Clock className="w-3 h-3" />
                            <span>{node.estimatedWeeks}w</span>
                          </Badge>
                          {isNodeCompleted && (
                            <Badge
                              variant="default"
                              className="bg-green-500 text-xs animate-in slide-in-from-right-2 duration-300"
                            >
                              <Icons.Trophy className="w-3 h-3 mr-1" />
                              Complete
                            </Badge>
                          )}
                        </div>
                      </div>
                      <CardDescription className="text-sm text-pretty">{node.summary}</CardDescription>
                    </CardHeader>

                    {node.children && (
                      <CardContent className="pt-0">
                        <div className="space-y-2">
                          <div className="flex items-center space-x-2 text-sm font-medium text-muted-foreground mb-3">
                            <Icons.BookOpen className="w-4 h-4" />
                            <span>Skills to Master</span>
                          </div>
                          <div className="grid gap-2">
                            {node.children.map((child, childIndex) => {
                              const isChildCompleted = completedSteps.has(child.id)
                              const isChildAnimating = animatingSteps.has(child.id)
                              return (
                                <button
                                  key={child.id}
                                  onClick={() => toggleStepCompletion(child.id)}
                                  className={cn(
                                    "flex items-center justify-between p-2 md:p-3 rounded-md transition-all duration-200 text-left group",
                                    "hover:scale-[1.02] active:scale-[0.98]",
                                    isChildCompleted
                                      ? "bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800"
                                      : "bg-muted/50 hover:bg-muted",
                                    isChildAnimating && "scale-[1.02] animate-pulse",
                                  )}
                                  style={{
                                    animationDelay: `${childIndex * 50}ms`,
                                  }}
                                >
                                  <div className="flex items-center space-x-2 md:space-x-3 flex-1 min-w-0">
                                    {isChildCompleted ? (
                                      <Icons.CheckCircle className="w-3 h-3 md:w-4 md:h-4 text-green-500 flex-shrink-0 animate-in zoom-in-50 duration-200" />
                                    ) : (
                                      <Icons.Circle className="w-3 h-3 md:w-4 md:h-4 text-muted-foreground flex-shrink-0 group-hover:text-primary transition-colors duration-200" />
                                    )}
                                    <span
                                      className={cn(
                                        "text-xs md:text-sm font-medium truncate transition-all duration-200",
                                        isChildCompleted && "line-through text-muted-foreground",
                                      )}
                                    >
                                      {child.title}
                                    </span>
                                  </div>
                                  <Badge variant="outline" className="text-xs flex-shrink-0">
                                    <Icons.Clock className="w-2 h-2 mr-1" />
                                    {child.estimatedWeeks}w
                                  </Badge>
                                </button>
                              )
                            })}
                          </div>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                )
              })}
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-border">
            <SkillTreeVisualization
              skills={getSkillsForRole(role.id)}
              onSkillSelect={(skill) => {
                console.log("Selected skill:", skill)
              }}
            />
          </div>
        </div>
      )}
    </div>
  )
}
