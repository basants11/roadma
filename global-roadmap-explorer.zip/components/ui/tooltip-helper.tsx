"use client"

import type * as React from "react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export { TooltipProvider }

interface TooltipHelperProps {
  content: string
  type?: "help" | "info" | "tip"
  side?: "top" | "right" | "bottom" | "left"
  className?: string
  children?: React.ReactNode
}

export function TooltipHelper({ content, type = "help", side = "top", className = "", children }: TooltipHelperProps) {
  const icons = {
    help: "❓",
    info: "ℹ️",
    tip: "💡",
  }

  const icon = icons[type]

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          {children || (
            <button
              className={`inline-flex items-center justify-center w-4 h-4 rounded-full bg-muted hover:bg-muted/80 transition-colors ${className}`}
              aria-label={`${type} tooltip`}
            >
              <span className="text-xs">{icon}</span>
            </button>
          )}
        </TooltipTrigger>
        <TooltipContent side={side} className="max-w-xs text-sm">
          <p>{content}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
