"use client"

import * as React from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { TooltipHelper, TooltipProvider } from "@/components/ui/tooltip-helper"

interface FormFieldProps {
  id?: string
  label: string
  type?: "text" | "email" | "password" | "textarea"
  placeholder?: string
  microcopy?: string
  tooltip?: string
  value?: string
  onChange?: (value: string) => void
  error?: string
  success?: string
  required?: boolean
  maxLength?: number
  className?: string
  icon?: React.ReactNode
  onKeyDown?: (e: React.KeyboardEvent) => void
}

export function FormField({
  id = "form-field",
  label,
  type = "text",
  placeholder,
  microcopy,
  tooltip,
  value,
  onChange,
  error,
  success,
  required,
  maxLength,
  className = "",
  icon,
  onKeyDown,
}: FormFieldProps) {
  const [focused, setFocused] = React.useState(false)
  const [touched, setTouched] = React.useState(false)

  const showError = error && touched
  const showSuccess = success && touched && !error

  return (
    <div className={`space-y-2 ${className}`}>
      <div className="flex items-center gap-2">
        <Label htmlFor={id} className="text-sm font-medium">
          {label}
          {required && <span className="text-destructive ml-1">*</span>}
        </Label>
        {tooltip && (
          <TooltipProvider>
            <TooltipHelper content={tooltip} type="help" />
          </TooltipProvider>
        )}
      </div>

      <div className="relative">
        {type === "textarea" ? (
          <Textarea
            id={id}
            placeholder={placeholder}
            value={value}
            onChange={(e) => onChange?.(e.target.value)}
            onFocus={() => setFocused(true)}
            onBlur={() => {
              setFocused(false)
              setTouched(true)
            }}
            onKeyDown={onKeyDown}
            maxLength={maxLength}
            className={`transition-all duration-200 ${
              focused ? "ring-2 ring-primary/20 border-primary" : ""
            } ${showError ? "border-destructive" : ""} ${showSuccess ? "border-green-500" : ""}`}
            aria-describedby={microcopy || error || success ? `${id}-description` : undefined}
          />
        ) : (
          <div className="relative">
            {icon && <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</div>}
            <Input
              id={id}
              type={type}
              placeholder={placeholder}
              value={value}
              onChange={(e) => onChange?.(e.target.value)}
              onFocus={() => setFocused(true)}
              onBlur={() => {
                setFocused(false)
                setTouched(true)
              }}
              onKeyDown={onKeyDown}
              maxLength={maxLength}
              className={`transition-all duration-200 ${icon ? "pl-10" : ""} ${
                focused ? "ring-2 ring-primary/20 border-primary" : ""
              } ${showError ? "border-destructive" : ""} ${showSuccess ? "border-green-500" : ""}`}
              aria-describedby={microcopy || error || success ? `${id}-description` : undefined}
            />
          </div>
        )}

        {showSuccess && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-lg">✅</span>}
        {showError && <span className="absolute right-3 top-1/2 -translate-y-1/2 text-lg">⚠️</span>}
      </div>

      <div id={`${id}-description`} className="min-h-[1.25rem]">
        {showError && (
          <p className="text-sm text-destructive flex items-center gap-1">
            <span>⚠️</span>
            {error}
          </p>
        )}
        {showSuccess && !error && (
          <p className="text-sm text-green-600 flex items-center gap-1">
            <span>✅</span>
            {success}
          </p>
        )}
        {!showError && !showSuccess && microcopy && <p className="text-sm text-muted-foreground">{microcopy}</p>}
        {maxLength && value && (
          <p className="text-xs text-muted-foreground text-right">
            {value.length}/{maxLength}
          </p>
        )}
      </div>
    </div>
  )
}
