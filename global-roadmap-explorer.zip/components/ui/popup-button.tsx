"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface PopupButtonProps extends React.ComponentProps<typeof Button> {
  popupText?: string
  showRipple?: boolean
  bounceOnClick?: boolean
  glowEffect?: boolean
  successFeedback?: boolean
  magneticEffect?: boolean
  onSuccess?: () => void
}

export function PopupButton({
  children,
  className,
  popupText,
  showRipple = true,
  bounceOnClick = true,
  glowEffect = false,
  successFeedback = false,
  magneticEffect = false,
  onSuccess,
  onClick,
  ...props
}: PopupButtonProps) {
  const [isClicked, setIsClicked] = useState(false)
  const [showPopup, setShowPopup] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [ripples, setRipples] = useState<Array<{ id: number; x: number; y: number }>>([])
  const buttonRef = useRef<HTMLButtonElement>(null)

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    // Bounce animation
    if (bounceOnClick) {
      setIsClicked(true)
      setTimeout(() => setIsClicked(false), 200)
    }

    // Enhanced ripple effect
    if (showRipple) {
      const rect = e.currentTarget.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const newRipple = { id: Date.now(), x, y }

      setRipples((prev) => [...prev, newRipple])
      setTimeout(() => {
        setRipples((prev) => prev.filter((ripple) => ripple.id !== newRipple.id))
      }, 800)
    }

    // Enhanced popup text
    if (popupText) {
      setShowPopup(true)
      setTimeout(() => setShowPopup(false), 2500)
    }

    // Enhanced success feedback
    if (successFeedback) {
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 2000)
      setTimeout(() => onSuccess?.(), 500)
    }

    onClick?.(e)
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!magneticEffect || !buttonRef.current) return

    const rect = buttonRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left - rect.width / 2
    const y = e.clientY - rect.top - rect.height / 2

    setMousePosition({ x: x * 0.1, y: y * 0.1 })
  }

  const handleMouseEnter = () => {
    setIsHovered(true)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
    setMousePosition({ x: 0, y: 0 })
  }

  return (
    <div className="relative inline-block">
      <Button
        ref={buttonRef}
        className={cn(
          "relative overflow-hidden transition-all duration-300 ease-out",
          isClicked && bounceOnClick && "scale-95",
          glowEffect && "shadow-lg hover:shadow-xl hover:shadow-primary/25",
          showSuccess && "bg-green-500 hover:bg-green-600 text-white",
          magneticEffect && "transform-gpu",
          isHovered && glowEffect && "shadow-2xl shadow-primary/30",
          className,
        )}
        style={
          magneticEffect
            ? {
                transform: `translate(${mousePosition.x}px, ${mousePosition.y}px) ${isClicked ? "scale(0.95)" : "scale(1)"}`,
              }
            : undefined
        }
        onClick={handleClick}
        onMouseMove={handleMouseMove}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        {...props}
      >
        {showRipple &&
          ripples.map((ripple) => (
            <span
              key={ripple.id}
              className="absolute rounded-full bg-white/40 pointer-events-none animate-ping"
              style={{
                left: ripple.x - 15,
                top: ripple.y - 15,
                width: 30,
                height: 30,
                animationDuration: "0.8s",
                animationTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
              }}
            />
          ))}

        {glowEffect && isHovered && (
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-primary/10 to-primary/20 animate-pulse" />
        )}

        <span
          className={cn(
            "relative z-10 transition-all duration-300 flex items-center justify-center gap-2",
            showSuccess && "text-white",
            isHovered && "scale-105",
          )}
        >
          {showSuccess ? <span className="animate-in zoom-in-50 duration-300">✓ Success!</span> : children}
        </span>
      </Button>

      {showPopup && popupText && (
        <div className="absolute -top-14 left-1/2 transform -translate-x-1/2 z-50 animate-in fade-in-0 zoom-in-95 slide-in-from-bottom-2 duration-300">
          <div className="bg-black/90 backdrop-blur-sm text-white text-sm px-4 py-2 rounded-lg shadow-xl whitespace-nowrap border border-white/10">
            {popupText}
            <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/90" />
          </div>
        </div>
      )}

      {isClicked && !showSuccess && (
        <div className="absolute inset-0 bg-black/10 rounded-md animate-pulse pointer-events-none" />
      )}
    </div>
  )
}
