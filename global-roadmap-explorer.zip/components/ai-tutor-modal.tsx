"use client"
import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { CreateWithAI } from "./ai-tutor-features/create-with-ai"
import { TestSkills } from "./ai-tutor-features/test-skills"
import { AISearchBox } from "./ai-search-box"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface AITutorModalProps {
  isOpen: boolean
  onClose: () => void
  feature: string
}

export function AITutorModal({ isOpen, onClose, feature }: AITutorModalProps) {
  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true)
      const timer = setTimeout(() => setIsAnimating(false), 300)
      return () => clearTimeout(timer)
    }
  }, [isOpen])

  const getFeatureContent = () => {
    switch (feature) {
      case "create":
        return (
          <div className="animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
            <CreateWithAI />
          </div>
        )
      case "test":
        return (
          <div className="animate-in fade-in-0 slide-in-from-bottom-4 duration-500">
            <TestSkills />
          </div>
        )
      case "ask":
        return (
          <Card className="border-border/50 bg-card/90 backdrop-blur-sm animate-in fade-in-0 slide-in-from-bottom-4 duration-500 hover:shadow-lg transition-all">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span className="text-lg relative">
                  💬<span className="text-xs text-purple-300 absolute -top-1 -right-1 animate-pulse">✨</span>
                </span>
                <span>Ask AI Tutor</span>
                <Badge variant="secondary" className="bg-purple-500/10 text-purple-600 animate-pulse">
                  Career Guidance
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AISearchBox placeholder="Ask about career paths, resume tips, interview prep..." />
            </CardContent>
          </Card>
        )
      case "roadmap-chat":
        return (
          <Card className="border-border/50 bg-card/90 backdrop-blur-sm animate-in fade-in-0 slide-in-from-bottom-4 duration-500 hover:shadow-lg transition-all">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <span className="text-lg relative">
                  🗺️
                  <span className="text-xs text-orange-300 absolute -top-1 -right-1 animate-pulse">✨</span>
                </span>
                <span>Roadmap Chat</span>
                <Badge variant="secondary" className="bg-orange-500/10 text-orange-600 animate-pulse">
                  Interactive
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AISearchBox placeholder="Ask about any learning roadmap or career path..." />
            </CardContent>
          </Card>
        )
      default:
        return (
          <div className="text-center py-8 animate-in fade-in-0 duration-300">
            <span className="text-4xl">🤖</span>
            <p className="text-muted-foreground mt-4">Feature not found</p>
          </div>
        )
    }
  }

  const getFeatureTitle = () => {
    const titles = {
      create: "Create with AI",
      test: "Test my Skills",
      ask: "Ask AI Tutor",
      "roadmap-chat": "Roadmap Chat",
    }
    return titles[feature as keyof typeof titles] || "AI Tutor"
  }

  const getFeatureIcon = () => {
    const icons = {
      create: "🎯",
      test: "🧪",
      ask: "💬",
      "roadmap-chat": "🗺️",
    }
    return icons[feature as keyof typeof icons] || "🤖"
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={cn(
          "max-w-4xl max-h-[90vh] overflow-y-auto bg-background/95 backdrop-blur-md border-border/50 shadow-2xl",
          "animate-in fade-in-0 zoom-in-95 slide-in-from-bottom-8 duration-300",
          isAnimating && "animate-pulse",
        )}
      >
        <DialogHeader className="animate-in fade-in-0 slide-in-from-top-4 duration-500">
          <DialogTitle className="text-xl font-semibold flex items-center gap-3">
            <span className="text-2xl animate-bounce">{getFeatureIcon()}</span>
            <span className="bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent">
              {getFeatureTitle()}
            </span>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
              AI Powered
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="mt-6 relative">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-purple-500/5 rounded-lg -z-10" />
          {getFeatureContent()}
        </div>
      </DialogContent>
    </Dialog>
  )
}
