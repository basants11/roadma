import type { MetadataRoute } from "next"
import { getRoles } from "@/lib/mock-data"

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://global-roadmap-explorer.vercel.app"
  const roles = getRoles()

  // Generate sitemap entries for each role
  const rolePages = roles.slice(0, 100).map((role) => ({
    url: `${baseUrl}/role/${role.id}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: 0.8,
  }))

  return [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: "daily",
      priority: 1,
    },
    {
      url: `${baseUrl}/about`,
      lastModified: new Date(),
      changeFrequency: "monthly",
      priority: 0.5,
    },
    {
      url: `${baseUrl}/careers`,
      lastModified: new Date(),
      changeFrequency: "weekly",
      priority: 0.9,
    },
    ...rolePages,
  ]
}
