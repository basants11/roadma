import { type NextRequest, NextResponse } from "next/server"

// In-memory storage for demo purposes
// In production, you'd use a database
const subscribers = new Set<string>()

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    // Validate email
    if (!email || typeof email !== "string") {
      return NextResponse.json({ error: "Email is required" }, { status: 400 })
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ error: "Please enter a valid email address" }, { status: 400 })
    }

    // Check if already subscribed
    if (subscribers.has(email.toLowerCase())) {
      return NextResponse.json({ error: "This email is already subscribed" }, { status: 409 })
    }

    // Add to subscribers
    subscribers.add(email.toLowerCase())

    // In a real application, you would:
    // 1. Save to database
    // 2. Send confirmation email
    // 3. Integrate with email service (SendGrid, Mailchimp, etc.)

    console.log(`[v0] New subscriber: ${email}`)
    console.log(`[v0] Total subscribers: ${subscribers.size}`)

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    return NextResponse.json({
      success: true,
      message: "Successfully subscribed to notifications",
      totalSubscribers: subscribers.size,
    })
  } catch (error) {
    console.error("[v0] Subscription error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET() {
  return NextResponse.json({
    totalSubscribers: subscribers.size,
    message: "Subscription service is running",
  })
}
