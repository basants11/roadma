import { type NextRequest, NextResponse } from "next/server"
import { exec } from "child_process"
import { promisify } from "util"
import path from "path"

const execAsync = promisify(exec)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const streakCount = searchParams.get("streak") || "0"

    // Execute the Python script
    const scriptPath = path.join(process.cwd(), "scripts", "dynamic-content-generator.py")
    const { stdout, stderr } = await execAsync(`python3 "${scriptPath}"`)

    if (stderr) {
      console.error("Python script error:", stderr)
      return NextResponse.json({ error: "Failed to generate content" }, { status: 500 })
    }

    // Parse the JSON output from the Python script
    const dynamicContent = JSON.parse(stdout)

    // Add streak-specific milestones
    if (streakCount) {
      const generator = new (eval(`(${stdout.split("class DynamicContentGenerator:")[0]}DynamicContentGenerator)`))()
      dynamicContent.streak_milestones = generator.generate_streak_milestones(Number.parseInt(streakCount))
    }

    return NextResponse.json(dynamicContent)
  } catch (error) {
    console.error("Error executing dynamic content generator:", error)
    return NextResponse.json({ error: "Failed to generate dynamic content" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { type, data } = await request.json()

    // Handle different types of dynamic content requests
    switch (type) {
      case "challenge":
        return NextResponse.json({
          challenge: {
            id: `challenge_${Date.now()}`,
            title: "Build a React Component",
            description: "Create a reusable button component with TypeScript",
            difficulty: "Intermediate",
            estimated_time: "45 minutes",
            points: 25,
          },
        })

      case "motivation":
        const motivationalQuotes = [
          "Every expert was once a beginner.",
          "The only way to learn is by doing.",
          "Progress, not perfection.",
        ]
        return NextResponse.json({
          motivation: {
            quote: motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)],
            tip: "Break complex topics into smaller, manageable chunks",
            encouragement: "You're making great progress! Keep it up!",
          },
        })

      default:
        return NextResponse.json({ error: "Invalid content type" }, { status: 400 })
    }
  } catch (error) {
    console.error("Error processing dynamic content request:", error)
    return NextResponse.json({ error: "Failed to process request" }, { status: 500 })
  }
}
