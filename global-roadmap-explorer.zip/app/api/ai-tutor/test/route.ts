import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { skill } = await request.json()

    let questions = []

    try {
      // Try AI generation first
      const { generateText } = await import("ai")
      const { text } = await generateText({
        model: "openai/gpt-4o-mini",
        prompt: `Generate 5 multiple choice questions to test ${skill} knowledge.
        
        Return a JSON array where each question has:
        - question (string)
        - options (array of 4 strings)
        - correct (string - the correct answer)
        
        Make questions practical and relevant to real-world usage.`,
        maxTokens: 800,
        temperature: 0.7,
      })

      questions = JSON.parse(text)
    } catch (error) {
      console.log("AI generation failed, using fallback questions")

      // Fallback questions based on skill
      const fallbackQuestions = {
        JavaScript: [
          {
            question: "What is the correct way to declare a variable in JavaScript?",
            options: ["var x = 5;", "variable x = 5;", "v x = 5;", "declare x = 5;"],
            correct: "var x = 5;",
          },
          {
            question: "Which method is used to add an element to the end of an array?",
            options: ["push()", "add()", "append()", "insert()"],
            correct: "push()",
          },
        ],
        React: [
          {
            question: "What is JSX?",
            options: ["A JavaScript library", "A syntax extension for JavaScript", "A database", "A CSS framework"],
            correct: "A syntax extension for JavaScript",
          },
          {
            question: "Which hook is used for state management in functional components?",
            options: ["useEffect", "useState", "useContext", "useReducer"],
            correct: "useState",
          },
        ],
      }

      questions = fallbackQuestions[skill as keyof typeof fallbackQuestions] || [
        {
          question: `What is a key concept in ${skill}?`,
          options: ["Option A", "Option B", "Option C", "Option D"],
          correct: "Option A",
        },
      ]
    }

    return NextResponse.json({ questions })
  } catch (error) {
    console.error("Test generation error:", error)
    return NextResponse.json({ error: "Failed to generate test" }, { status: 500 })
  }
}
