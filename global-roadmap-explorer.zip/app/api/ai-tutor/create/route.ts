import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { topic, level } = await request.json()

    let learningPlan = null

    try {
      // Try AI generation first
      const { generateText } = await import("ai")
      const { text } = await generateText({
        model: "openai/gpt-4o-mini",
        prompt: `Create a personalized learning plan for "${topic}" at ${level} level. 
        
        Return a JSON object with:
        - duration (estimated time)
        - difficulty (beginner/intermediate/advanced)
        - projects (number of hands-on projects)
        - steps (array of learning steps with title and description)
        
        Make it practical and actionable.`,
        maxTokens: 600,
        temperature: 0.7,
      })

      learningPlan = JSON.parse(text)
    } catch (error) {
      console.log("AI generation failed, using structured fallback")

      // Fallback structured plan
      learningPlan = {
        duration: level === "beginner" ? "4-6 weeks" : level === "intermediate" ? "6-8 weeks" : "8-12 weeks",
        difficulty: level,
        projects: level === "beginner" ? 2 : level === "intermediate" ? 3 : 4,
        steps: [
          {
            title: `${topic} Fundamentals`,
            description: `Learn the core concepts and basics of ${topic}`,
          },
          {
            title: "Hands-on Practice",
            description: `Build practical projects to apply ${topic} knowledge`,
          },
          {
            title: "Advanced Concepts",
            description: `Dive deeper into advanced ${topic} techniques`,
          },
          {
            title: "Real-world Application",
            description: `Create a portfolio project showcasing your ${topic} skills`,
          },
        ],
      }
    }

    return NextResponse.json({ plan: learningPlan })
  } catch (error) {
    console.error("Create with AI error:", error)
    return NextResponse.json({ error: "Failed to generate learning plan" }, { status: 500 })
  }
}
