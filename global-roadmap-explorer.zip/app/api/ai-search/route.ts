import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Query is required and must be a string" }, { status: 400 })
    }

    try {
      // First try Vercel AI Gateway (free)
      const { generateText } = await import("ai")
      const { text } = await generateText({
        model: "openai/gpt-4o-mini",
        prompt: `You are an expert IT career advisor. User asks: "${query}"\n\nProvide actionable career advice with:\n• Role overview and skills needed\n• Learning path and timeline\n• Career progression\n• Current market trends\n\nKeep response concise, professional, and structured.`,
        maxTokens: 400,
        temperature: 0.7,
      })
      return NextResponse.json({ response: text })
    } catch (aiError) {
      console.log("[v0] AI Gateway failed, using fallback:", aiError)

      // Fallback to Hugging Face free API
      const response = await fetch("https://api-inference.huggingface.co/models/microsoft/DialoGPT-medium", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          inputs: `Career Advisor: ${query}`,
          parameters: {
            max_length: 200,
            temperature: 0.7,
            do_sample: true,
          },
        }),
      })

      if (!response.ok) {
        throw new Error("Hugging Face API failed")
      }

      const data = await response.json()
      let aiResponse = data[0]?.generated_text || "I'm here to help with your IT career questions!"

      // Clean up the response
      aiResponse = aiResponse.replace(`Career Advisor: ${query}`, "").trim()

      // If response is too short, provide a structured fallback
      if (aiResponse.length < 50) {
        aiResponse = generateStructuredResponse(query)
      }

      return NextResponse.json({ response: aiResponse })
    }
  } catch (error) {
    console.error("[v0] All AI services failed:", error)

    // Final fallback with structured responses
    const fallbackResponse = generateStructuredResponse(request.query || "career advice")
    return NextResponse.json({ response: fallbackResponse })
  }
}

function generateStructuredResponse(query: string): string {
  const lowerQuery = query.toLowerCase()

  if (lowerQuery.includes("frontend") || lowerQuery.includes("react") || lowerQuery.includes("javascript")) {
    return `**Frontend Developer Career Path:**

• **Essential Skills:** HTML, CSS, JavaScript, React/Vue/Angular, TypeScript
• **Learning Timeline:** 6-12 months for basics, 1-2 years for proficiency
• **Career Progression:** Junior → Mid-level → Senior → Lead/Architect
• **Current Trends:** React 18+, Next.js, TypeScript, Tailwind CSS
• **Salary Range:** $50k-$150k+ depending on experience and location

**Next Steps:** Build projects, contribute to open source, create a portfolio website.`
  }

  if (lowerQuery.includes("backend") || lowerQuery.includes("api") || lowerQuery.includes("server")) {
    return `**Backend Developer Career Path:**

• **Essential Skills:** Node.js/Python/Java, Databases, APIs, Cloud services
• **Learning Timeline:** 8-15 months for solid foundation
• **Career Progression:** Junior → Mid-level → Senior → Architect
• **Current Trends:** Microservices, Docker, Kubernetes, Serverless
• **Salary Range:** $60k-$160k+ depending on experience

**Next Steps:** Learn database design, build REST APIs, understand cloud platforms.`
  }

  if (lowerQuery.includes("ai") || lowerQuery.includes("machine learning") || lowerQuery.includes("ml")) {
    return `**AI/ML Engineer Career Path:**

• **Essential Skills:** Python, TensorFlow/PyTorch, Statistics, Data Analysis
• **Learning Timeline:** 12-24 months for strong foundation
• **Career Progression:** Junior ML → ML Engineer → Senior/Lead → Research
• **Current Trends:** LLMs, Computer Vision, MLOps, Edge AI
• **Salary Range:** $80k-$200k+ for experienced professionals

**Next Steps:** Master Python, learn ML fundamentals, work on real projects.`
  }

  if (lowerQuery.includes("devops") || lowerQuery.includes("cloud")) {
    return `**DevOps Engineer Career Path:**

• **Essential Skills:** Linux, Docker, Kubernetes, AWS/Azure, CI/CD
• **Learning Timeline:** 10-18 months for proficiency
• **Career Progression:** Junior → DevOps Engineer → Senior → Platform Architect
• **Current Trends:** GitOps, Infrastructure as Code, Observability
• **Salary Range:** $70k-$170k+ based on experience

**Next Steps:** Get cloud certifications, practice with containers, learn automation.`
  }

  // Generic career advice
  return `**IT Career Guidance:**

• **Popular Paths:** Frontend, Backend, Full-stack, DevOps, Data Science, Cybersecurity
• **Essential Skills:** Programming fundamentals, problem-solving, continuous learning
• **Getting Started:** Choose a specialization, build projects, create a portfolio
• **Career Growth:** Contribute to open source, network with professionals, stay updated with trends
• **Salary Potential:** $50k-$200k+ depending on role, experience, and location

**Next Steps:** Identify your interests, start with online courses, build practical projects.`
}
