import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { query, feature, journalEntry } = await request.json()

    // Enhanced AI responses based on feature type
    let systemPrompt = ""
    const userInput = query || journalEntry

    switch (feature) {
      case "fitness":
        systemPrompt =
          "You are a knowledgeable fitness coach. Provide personalized workout advice, nutrition tips, and motivation. Keep responses practical and encouraging."
        break
      case "productivity":
        systemPrompt =
          "You are a productivity expert. Share effective strategies, time management techniques, and tools to help users achieve their goals efficiently."
        break
      case "travel":
        systemPrompt =
          "You are an experienced travel advisor. Provide destination recommendations, travel tips, budget advice, and cultural insights."
        break
      case "news":
        systemPrompt =
          "You are a news curator. Summarize current events, explain complex topics simply, and provide balanced perspectives on important issues."
        break
      case "life":
        systemPrompt =
          "You are a wise life coach. Offer thoughtful guidance on personal growth, relationships, decision-making, and finding purpose."
        break
      case "journal":
        systemPrompt =
          "You are a compassionate journal companion. Provide thoughtful reflections, identify patterns, offer encouragement, and suggest insights for personal growth."
        break
      default:
        systemPrompt =
          "You are a helpful AI life companion. Provide thoughtful, practical advice on any topic the user asks about."
    }

    // Try multiple AI services with fallbacks
    let response = ""

    try {
      // Primary: Use Vercel AI Gateway
      const aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.OPENAI_API_KEY || "fallback"}`,
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userInput },
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      })

      if (aiResponse.ok) {
        const data = await aiResponse.json()
        response = data.choices[0]?.message?.content || ""
      }
    } catch (error) {
      console.log("Primary AI service unavailable, using fallback")
    }

    // Fallback: Provide structured responses
    if (!response) {
      switch (feature) {
        case "fitness":
          response = `Great question about fitness! Here are some personalized recommendations:

🏃‍♂️ **Workout Plan**: Start with 20-30 minutes of cardio 3x per week, plus 2 strength training sessions focusing on compound movements like squats, deadlifts, and push-ups.

🥗 **Nutrition**: Focus on whole foods - lean proteins, complex carbs, healthy fats, and plenty of vegetables. Stay hydrated with 8+ glasses of water daily.

💪 **Progress Tips**: Track your workouts, get 7-9 hours of sleep, and be consistent rather than perfect. Small daily improvements lead to big results!

Remember: Listen to your body and consult a healthcare provider before starting any new fitness program.`
          break

        case "productivity":
          response = `Here's how to boost your productivity effectively:

⏰ **Time Management**: Try the Pomodoro Technique - work for 25 minutes, then take a 5-minute break. This maintains focus and prevents burnout.

📋 **Prioritization**: Use the Eisenhower Matrix to categorize tasks by urgency and importance. Focus on important tasks first.

🎯 **Goal Setting**: Break large projects into smaller, actionable steps. Set SMART goals (Specific, Measurable, Achievable, Relevant, Time-bound).

🚫 **Eliminate Distractions**: Turn off notifications during focused work time, use website blockers, and create a dedicated workspace.

The key is consistency - small improvements in your daily routine compound over time!`
          break

        case "travel":
          response = `Exciting travel plans ahead! Here's my advice:

✈️ **Destination Ideas**: 
- **Spring**: Japan (cherry blossoms), Netherlands (tulips)
- **Summer**: Portugal (great weather, lower costs), Eastern Europe
- **Fall**: India (post-monsoon), Morocco (cooler temps)
- **Winter**: Southeast Asia, New Zealand, Patagonia

💰 **Budget Tips**: 
- Book flights 6-8 weeks in advance
- Use travel comparison sites
- Consider shoulder seasons for better prices
- Try local street food and public transport

📱 **Essential Apps**: Google Translate, Maps.me (offline maps), XE Currency, TripAdvisor

🎒 **Packing**: Pack light, bring versatile clothing, and always have copies of important documents.

Where are you thinking of going? I can provide more specific recommendations!`
          break

        case "journal":
          response = `Thank you for sharing your thoughts with me. Reflecting on your day is a powerful practice for personal growth.

🌟 **What I Notice**: Your entry shows self-awareness and a desire for growth - these are wonderful qualities that will serve you well.

💭 **Reflection Questions**:
- What was the highlight of your day?
- What challenged you, and how did you handle it?
- What are you grateful for today?
- What would you like to improve tomorrow?

🎯 **Tomorrow's Focus**: Consider setting one small, achievable goal for tomorrow based on today's experiences.

📈 **Growth Pattern**: I encourage you to journal regularly - even just a few sentences daily can help you track patterns, celebrate progress, and gain clarity on your path forward.

Remember, every day is a new opportunity to learn and grow. You're doing great by taking time to reflect!`
          break

        default:
          response = `I'm here to help you with whatever you need! As your AI life companion, I can assist with:

🏃‍♂️ **Fitness & Health**: Workout plans, nutrition advice, wellness tips
📈 **Productivity**: Time management, goal setting, efficiency strategies  
✈️ **Travel**: Destination recommendations, planning tips, cultural insights
📰 **News & Trends**: Current events, technology updates, industry insights
💭 **Life Advice**: Personal growth, decision-making, relationship guidance
📔 **Daily Reflection**: Journal insights, pattern recognition, encouragement

Feel free to ask me anything specific, or choose one of the categories above to get started. I'm here to provide personalized guidance tailored to your needs and goals.

What would you like to explore today?`
      }
    }

    return NextResponse.json({
      response,
      feature,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("AI Companion API Error:", error)
    return NextResponse.json(
      { error: "I'm having trouble processing your request right now. Please try again in a moment." },
      { status: 500 },
    )
  }
}
