import type React from "react"
import type { Metadata } from "next"
import { Inter, JetBrains_Mono } from "next/font/google"
import { Suspense } from "react"
import "./globals.css"

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
})

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  display: "swap",
})

export const metadata: Metadata = {
  title: "Global Roadmap Explorer - Career Roadmaps for 1,000+ IT Roles | Learn. Grow. Master.",
  description:
    "Discover personalized career roadmaps for 1,000+ IT roles including AI Developer, Cloud Architect, Cybersecurity Analyst, and more. Generate custom learning paths with timelines, projects, and skill requirements.",
  keywords: [
    "career roadmap",
    "IT careers",
    "software developer roadmap",
    "AI developer path",
    "cloud architect career",
    "cybersecurity roadmap",
    "programming career guide",
    "tech career planning",
    "developer learning path",
    "IT professional development",
    "coding bootcamp alternative",
    "tech skills roadmap",
  ],
  authors: [{ name: "Global Roadmap Explorer Team" }],
  creator: "Global Roadmap Explorer",
  publisher: "Global Roadmap Explorer",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://global-roadmap-explorer.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Global Roadmap Explorer - Career Roadmaps for 1,000+ IT Roles",
    description:
      "Discover personalized career roadmaps for 1,000+ IT roles. Generate custom learning paths with timelines, projects, and skill requirements.",
    url: "https://global-roadmap-explorer.vercel.app",
    siteName: "Global Roadmap Explorer",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Global Roadmap Explorer - Career Roadmaps for IT Professionals",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Global Roadmap Explorer - Career Roadmaps for 1,000+ IT Roles",
    description:
      "Discover personalized career roadmaps for 1,000+ IT roles. Generate custom learning paths with timelines and skill requirements.",
    images: ["/og-image.jpg"],
    creator: "@roadmapexplorer",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  verification: {
    google: "your-google-verification-code",
    yandex: "your-yandex-verification-code",
  },
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebApplication",
              name: "Global Roadmap Explorer",
              description:
                "Discover personalized career roadmaps for 1,000+ IT roles including AI Developer, Cloud Architect, Cybersecurity Analyst, and more.",
              url: "https://global-roadmap-explorer.vercel.app",
              applicationCategory: "EducationalApplication",
              operatingSystem: "Web Browser",
              offers: {
                "@type": "Offer",
                price: "0",
                priceCurrency: "USD",
              },
              author: {
                "@type": "Organization",
                name: "Global Roadmap Explorer Team",
              },
              publisher: {
                "@type": "Organization",
                name: "Global Roadmap Explorer",
              },
              potentialAction: {
                "@type": "SearchAction",
                target: "https://global-roadmap-explorer.vercel.app/?search={search_term_string}",
                "query-input": "required name=search_term_string",
              },
              audience: {
                "@type": "Audience",
                audienceType: "IT Professionals, Students, Career Changers",
              },
              educationalUse: "Career Planning, Skill Development, Professional Growth",
              learningResourceType: "Career Roadmap, Learning Path, Skill Guide",
            }),
          }}
        />
        <link rel="canonical" href="https://global-roadmap-explorer.vercel.app" />
        <meta name="theme-color" content="#000000" />
        <meta name="color-scheme" content="dark light" />
      </head>
      <body className={`font-sans ${inter.variable} ${jetbrainsMono.variable} antialiased`}>
        <Suspense fallback={null}>{children}</Suspense>
      </body>
    </html>
  )
}
