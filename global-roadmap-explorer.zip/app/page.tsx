"use client"

import { Badge } from "@/components/ui/badge"
import { useState, useCallback } from "react"
import { ResponsiveLayout } from "@/components/responsive-layout"
import { RoadmapGenerator } from "@/components/roadmap-generator"
import { WelcomeHero } from "@/components/welcome-hero"
import { CommunitySection } from "@/components/community-section"
import { ActivelyMaintainedSection } from "@/components/actively-maintained-section"
import { getRoles, type Role, type RoadmapNode } from "@/lib/mock-data"

export default function GlobalRoadmapExplorer() {
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredRoles, setFilteredRoles] = useState<Role[]>(getRoles())
  const [selectedRole, setSelectedRole] = useState<Role | null>(null)
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleNode = useCallback((nodeId: string) => {
    setExpandedNodes((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(nodeId)) {
        newSet.delete(nodeId)
      } else {
        newSet.add(nodeId)
      }
      return newSet
    })
  }, [])

  const handleRoleSelect = useCallback((role: Role | null) => {
    setSelectedRole(role)
  }, [])

  const handleRoadmapGenerated = useCallback((roadmap: RoadmapNode[]) => {
    console.log("Roadmap generated:", roadmap)
  }, [])

  const handleFilteredRoles = useCallback((roles: Role[]) => {
    setFilteredRoles(roles)
  }, [])

  const handleAISearch = useCallback((query: string) => {
    // For now, just update the search query - could be enhanced with AI processing
    setSearchQuery(query)

    // Find matching roles based on AI query
    const matchingRoles = getRoles().filter(
      (role) =>
        role.title.toLowerCase().includes(query.toLowerCase()) ||
        role.description.toLowerCase().includes(query.toLowerCase()) ||
        role.category.toLowerCase().includes(query.toLowerCase()),
    )

    if (matchingRoles.length > 0) {
      setFilteredRoles(matchingRoles)
      // Auto-select first matching role if it's a specific query
      if (matchingRoles.length === 1) {
        setSelectedRole(matchingRoles[0])
      }
    }
  }, [])

  const handleUserOnboarded = useCallback((userData: Record<string, string>) => {
    console.log("User onboarded:", userData)
    // Could trigger personalized recommendations based on user data
  }, [])

  return (
    <>
      <main role="main" aria-label="Global Roadmap Explorer">
        <ResponsiveLayout
          roles={getRoles()}
          filteredRoles={filteredRoles}
          selectedRole={selectedRole}
          searchQuery={searchQuery}
          expandedNodes={expandedNodes}
          onRoleSelect={handleRoleSelect}
          onToggleNode={toggleNode}
          onFilteredRoles={handleFilteredRoles}
          onSearchQueryChange={setSearchQuery}
        >
          {selectedRole ? (
            <article className="p-4 md:p-6 max-w-4xl mx-auto" itemScope itemType="https://schema.org/Article">
              {/* Role Header - Hidden on mobile as it's in the header */}
              <header className="mb-6 md:mb-8 hidden md:block">
                <Badge variant="outline" className="mb-2">
                  <span itemProp="articleSection">{selectedRole.category}</span>
                </Badge>
                <h1 className="text-2xl md:text-3xl font-bold text-balance mb-2" itemProp="headline">
                  {selectedRole.title} Career Roadmap
                </h1>
                <p className="text-muted-foreground text-pretty leading-relaxed mb-4" itemProp="description">
                  {selectedRole.description}
                </p>

                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <Badge variant="secondary" itemProp="skillLevel">
                    {selectedRole.level} level
                  </Badge>
                  <span itemProp="timeRequired">Est. {selectedRole.estimatedWeeks} weeks to master</span>
                </div>
              </header>

              {/* Mobile Role Details */}
              <div className="mb-6 md:hidden">
                <h1 className="sr-only">{selectedRole.title} Career Roadmap</h1>
                <p className="text-sm text-muted-foreground text-pretty leading-relaxed mb-4" itemProp="description">
                  {selectedRole.description}
                </p>
                <div className="flex items-center space-x-2 text-xs">
                  <Badge variant="secondary" className="text-xs" itemProp="skillLevel">
                    {selectedRole.level}
                  </Badge>
                  <span className="text-muted-foreground" itemProp="timeRequired">
                    {selectedRole.estimatedWeeks}w to master
                  </span>
                </div>
              </div>

              {/* Roadmap Generator */}
              <section aria-label="Personalized Roadmap Generator">
                <RoadmapGenerator role={selectedRole} onRoadmapGenerated={handleRoadmapGenerated} />
              </section>
            </article>
          ) : (
            <div>
              {/* Replaced welcome section with new friendly WelcomeHero component */}
              <WelcomeHero onGetStarted={handleUserOnboarded} />

              <CommunitySection />

              <ActivelyMaintainedSection />
            </div>
          )}
        </ResponsiveLayout>
      </main>
    </>
  )
}
