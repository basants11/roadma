export interface Role {
  id: string
  title: string
  category: string
  description: string
  hasChildren: boolean
  estimatedWeeks?: number
  level?: "entry" | "mid" | "senior" | "expert"
  children?: Role[]
}

export interface RoadmapNode {
  id: string
  title: string
  summary: string
  estimatedWeeks: number
  hasChildren: boolean
  children?: RoadmapNode[]
}

// Categories for IT roles
const categories = [
  "Software Engineering",
  "AI & Machine Learning",
  "Cloud & Infrastructure",
  "Cybersecurity",
  "Data Science & Analytics",
  "DevOps & SRE",
  "Mobile Development",
  "Web Development",
  "Game Development",
  "Product & Design",
  "Quality Assurance",
  "Network Engineering",
  "Database Administration",
  "Blockchain & Web3",
  "IoT & Embedded Systems",
]

// Base role templates for each category
const roleTemplates = {
  "Software Engineering": [
    "Frontend Developer",
    "Backend Developer",
    "Full Stack Developer",
    "Software Architect",
    "Systems Engineer",
    "Platform Engineer",
    "API Developer",
    "Microservices Developer",
  ],
  "AI & Machine Learning": [
    "AI Developer",
    "Machine Learning Engineer",
    "Data Scientist",
    "MLOps Engineer",
    "Computer Vision Engineer",
    "NLP Engineer",
    "AI Research Scientist",
    "Prompt Engineer",
  ],
  "Cloud & Infrastructure": [
    "Cloud Architect",
    "AWS Developer",
    "Azure Developer",
    "GCP Developer",
    "Infrastructure Engineer",
    "Cloud Security Engineer",
    "Serverless Developer",
  ],
  Cybersecurity: [
    "Security Analyst",
    "Penetration Tester",
    "Security Engineer",
    "CISO",
    "Incident Response Specialist",
    "Security Architect",
    "Compliance Officer",
  ],
  "Data Science & Analytics": [
    "Data Analyst",
    "Business Intelligence Developer",
    "Data Engineer",
    "Analytics Engineer",
    "Quantitative Analyst",
    "Research Scientist",
    "Statistician",
  ],
  "DevOps & SRE": [
    "DevOps Engineer",
    "Site Reliability Engineer",
    "Build Engineer",
    "Release Manager",
    "Infrastructure Automation Engineer",
    "Monitoring Engineer",
    "Platform Engineer",
  ],
  "Mobile Development": [
    "iOS Developer",
    "Android Developer",
    "React Native Developer",
    "Flutter Developer",
    "Mobile Architect",
    "Mobile Security Engineer",
    "Cross-Platform Developer",
  ],
  "Web Development": [
    "React Developer",
    "Vue Developer",
    "Angular Developer",
    "Node.js Developer",
    "WordPress Developer",
    "Shopify Developer",
    "JAMstack Developer",
  ],
  "Game Development": [
    "Game Developer",
    "Unity Developer",
    "Unreal Developer",
    "Game Designer",
    "Graphics Programmer",
    "Gameplay Programmer",
    "Technical Artist",
  ],
  "Product & Design": [
    "Product Manager",
    "UX Designer",
    "UI Designer",
    "Product Designer",
    "Design Systems Engineer",
    "User Researcher",
    "Product Owner",
  ],
  "Quality Assurance": [
    "QA Engineer",
    "Test Automation Engineer",
    "Performance Tester",
    "Security Tester",
    "QA Manager",
    "Test Architect",
    "Manual Tester",
  ],
  "Network Engineering": [
    "Network Engineer",
    "Network Architect",
    "Network Security Engineer",
    "NOC Engineer",
    "Wireless Engineer",
    "VoIP Engineer",
    "SD-WAN Engineer",
  ],
  "Database Administration": [
    "Database Administrator",
    "Database Developer",
    "Data Architect",
    "Database Analyst",
    "NoSQL Developer",
    "Database Security Specialist",
    "Performance Tuning Specialist",
  ],
  "Blockchain & Web3": [
    "Blockchain Developer",
    "Smart Contract Developer",
    "DeFi Developer",
    "Web3 Developer",
    "Cryptocurrency Analyst",
    "Blockchain Architect",
    "NFT Developer",
  ],
  "IoT & Embedded Systems": [
    "IoT Developer",
    "Embedded Systems Engineer",
    "Firmware Developer",
    "Hardware Engineer",
    "Robotics Engineer",
    "Edge Computing Engineer",
    "Industrial IoT Specialist",
  ],
}

// Generate comprehensive role data
export function generateRoles(): Role[] {
  const roles: Role[] = []
  let idCounter = 1

  categories.forEach((category) => {
    const templates = roleTemplates[category as keyof typeof roleTemplates] || []

    templates.forEach((template) => {
      // Generate multiple variations and seniority levels
      const levels = ["Junior", "Mid-Level", "Senior", "Lead", "Principal"]
      const specializations = ["Frontend", "Backend", "Full Stack", "Specialist", "Architect"]

      levels.forEach((level) => {
        if (Math.random() > 0.3) {
          // Don't generate every combination
          const role: Role = {
            id: `role-${idCounter++}`,
            title: `${level} ${template}`,
            category,
            description: generateRoleDescription(level, template, category),
            hasChildren: true,
            estimatedWeeks: Math.floor(Math.random() * 48) + 12, // 12-60 weeks
            level: level.toLowerCase().includes("junior")
              ? "entry"
              : level.toLowerCase().includes("senior") || level.toLowerCase().includes("lead")
                ? "senior"
                : level.toLowerCase().includes("principal")
                  ? "expert"
                  : "mid",
          }
          roles.push(role)
        }
      })

      // Add some specialized roles
      if (Math.random() > 0.5) {
        specializations.forEach((spec) => {
          if (Math.random() > 0.6) {
            const role: Role = {
              id: `role-${idCounter++}`,
              title: `${spec} ${template}`,
              category,
              description: generateRoleDescription(spec, template, category),
              hasChildren: true,
              estimatedWeeks: Math.floor(Math.random() * 36) + 16,
              level: "mid",
            }
            roles.push(role)
          }
        })
      }
    })
  })

  return roles.slice(0, 1200) // Ensure we have 1000+ roles
}

function generateRoleDescription(level: string, role: string, category: string): string {
  const descriptions = [
    `Expert in ${category.toLowerCase()} with focus on ${role.toLowerCase()}. Build scalable solutions and lead technical initiatives.`,
    `Specialized ${role.toLowerCase()} professional working with cutting-edge ${category.toLowerCase()} technologies and methodologies.`,
    `${level} ${role.toLowerCase()} responsible for designing, developing, and maintaining enterprise-grade ${category.toLowerCase()} systems.`,
    `Experienced ${role.toLowerCase()} with deep expertise in ${category.toLowerCase()}, driving innovation and technical excellence.`,
    `${role} focused on ${category.toLowerCase()} solutions, collaborating with cross-functional teams to deliver high-quality products.`,
  ]

  return descriptions[Math.floor(Math.random() * descriptions.length)]
}

// Generate roadmap nodes for a specific role
export function generateRoadmapNodes(roleId: string): RoadmapNode[] {
  const roadmapCategories = [
    "Foundations",
    "Core Skills",
    "Advanced Concepts",
    "Practical Projects",
    "Specializations",
    "Interview Preparation",
  ]

  return roadmapCategories.map((category, index) => ({
    id: `${roleId}-roadmap-${index}`,
    title: category,
    summary: generateRoadmapSummary(category),
    estimatedWeeks: Math.floor(Math.random() * 8) + 2, // 2-10 weeks per category
    hasChildren: true,
    children: generateSubRoadmapNodes(`${roleId}-roadmap-${index}`, category),
  }))
}

function generateSubRoadmapNodes(parentId: string, category: string): RoadmapNode[] {
  const subNodes: { [key: string]: string[] } = {
    Foundations: [
      "Programming Basics",
      "Computer Science Fundamentals",
      "Development Environment Setup",
      "Version Control",
    ],
    "Core Skills": ["Primary Technologies", "Frameworks & Libraries", "Best Practices", "Testing Methodologies"],
    "Advanced Concepts": ["Architecture Patterns", "Performance Optimization", "Security Principles", "Scalability"],
    "Practical Projects": [
      "Portfolio Projects",
      "Open Source Contributions",
      "Real-world Applications",
      "Code Reviews",
    ],
    Specializations: ["Domain Expertise", "Advanced Tools", "Industry Standards", "Emerging Technologies"],
    "Interview Preparation": [
      "Technical Interviews",
      "System Design",
      "Behavioral Questions",
      "Portfolio Presentation",
    ],
  }

  const items = subNodes[category] || ["Skill 1", "Skill 2", "Skill 3"]

  return items.map((item, index) => ({
    id: `${parentId}-sub-${index}`,
    title: item,
    summary: `Master ${item.toLowerCase()} through hands-on practice and real-world applications.`,
    estimatedWeeks: Math.floor(Math.random() * 3) + 1, // 1-4 weeks per skill
    hasChildren: false,
  }))
}

function generateRoadmapSummary(category: string): string {
  const summaries: { [key: string]: string } = {
    Foundations: "Build a solid foundation with essential programming concepts, tools, and methodologies.",
    "Core Skills": "Develop proficiency in key technologies, frameworks, and industry-standard practices.",
    "Advanced Concepts": "Master complex topics including architecture, optimization, and advanced design patterns.",
    "Practical Projects": "Apply your skills through hands-on projects and real-world development experience.",
    Specializations: "Dive deep into specialized areas and emerging technologies in your field.",
    "Interview Preparation": "Prepare for technical interviews and showcase your expertise to potential employers.",
  }

  return summaries[category] || `Comprehensive training in ${category.toLowerCase()} for professional development.`
}

// Cache for generated data
let cachedRoles: Role[] | null = null

export function getRoles(): Role[] {
  if (!cachedRoles) {
    cachedRoles = generateRoles()
  }
  return cachedRoles
}

export function searchRoles(query: string): Role[] {
  const roles = getRoles()
  const lowercaseQuery = query.toLowerCase()

  return roles.filter(
    (role) =>
      role.title.toLowerCase().includes(lowercaseQuery) ||
      role.category.toLowerCase().includes(lowercaseQuery) ||
      role.description.toLowerCase().includes(lowercaseQuery),
  )
}

export function getRoleById(id: string): Role | undefined {
  const roles = getRoles()
  return roles.find((role) => role.id === id)
}
